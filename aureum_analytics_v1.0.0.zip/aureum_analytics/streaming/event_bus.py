"""
AUREUM ANALYTICS — Event Bus & Pub/Sub
Redis-backed asynchronous event distribution for
real-time analytics updates and cross-service messaging.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from pydantic import BaseModel

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class AureumEvent(BaseModel):
    """Normalised event envelope for all AUREUM messages."""

    event_id: str
    event_type: str
    source: str
    payload: Dict[str, Any]
    timestamp: datetime
    priority: int = 0  # 0=normal, 1=elevated, 2=critical

    @classmethod
    def create(
        cls,
        event_type: str,
        source: str,
        payload: Dict[str, Any],
        priority: int = 0,
    ) -> "AureumEvent":
        return cls(
            event_id=str(uuid4())[:8],
            event_type=event_type,
            source=source,
            payload=payload,
            timestamp=datetime.now(timezone.utc),
            priority=priority,
        )

    def serialise(self) -> str:
        return self.model_dump_json()

    @classmethod
    def deserialise(cls, raw: str) -> "AureumEvent":
        return cls.model_validate_json(raw)


class InMemoryEventBus:
    """
    In-process event bus for development and testing.
    Drop-in replacement for Redis pub/sub when Redis is unavailable.
    """

    def __init__(self) -> None:
        self._subscribers: Dict[str, List[Callable]] = {}
        self._history: List[AureumEvent] = []
        self._max_history: int = 10_000

    def subscribe(
        self,
        channel: str,
        handler: Callable[[AureumEvent], Any],
    ) -> None:
        self._subscribers.setdefault(channel, []).append(handler)
        logger.debug("Subscribed", channel=channel, handler=handler.__name__)

    def unsubscribe(self, channel: str, handler: Callable) -> None:
        if channel in self._subscribers:
            self._subscribers[channel] = [
                h for h in self._subscribers[channel] if h != handler
            ]

    async def publish(self, channel: str, event: AureumEvent) -> int:
        """Dispatch event to all channel subscribers. Returns delivery count."""
        self._history.append(event)
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

        handlers = self._subscribers.get(channel, [])
        delivered = 0
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(event)
                else:
                    handler(event)
                delivered += 1
            except Exception as exc:
                logger.error(
                    "Event handler error",
                    channel=channel,
                    handler=handler.__name__,
                    error=str(exc),
                )

        logger.debug(
            "Event published",
            channel=channel,
            event_type=event.event_type,
            delivered=delivered,
        )
        return delivered

    def get_history(
        self,
        event_type: Optional[str] = None,
        limit: int = 100,
    ) -> List[AureumEvent]:
        events = self._history
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        return events[-limit:]


class RedisPubSub:
    """
    Redis-backed pub/sub implementation.
    Requires aioredis. Falls back to InMemoryEventBus if unavailable.
    """

    def __init__(self, redis_url: Optional[str] = None) -> None:
        self._url = redis_url or settings.REDIS_URL
        self._redis = None
        self._pubsub = None
        self._subscriptions: Dict[str, List[Callable]] = {}

    async def connect(self) -> None:
        try:
            import aioredis
            self._redis = await aioredis.from_url(self._url, decode_responses=True)
            self._pubsub = self._redis.pubsub()
            logger.info("Redis pub/sub connected", url=self._url)
        except ImportError:
            logger.warning("aioredis not available — pub/sub disabled")
        except Exception as exc:
            logger.error("Redis connection failed", error=str(exc))

    async def publish(self, channel: str, event: AureumEvent) -> None:
        if self._redis is None:
            return
        await self._redis.publish(channel, event.serialise())

    async def subscribe(self, channel: str) -> None:
        if self._pubsub:
            await self._pubsub.subscribe(channel)

    async def listen(self, handler: Callable[[AureumEvent], Any]) -> None:
        if not self._pubsub:
            return
        async for message in self._pubsub.listen():
            if message["type"] == "message":
                try:
                    event = AureumEvent.deserialise(message["data"])
                    if asyncio.iscoroutinefunction(handler):
                        await handler(event)
                    else:
                        handler(event)
                except Exception as exc:
                    logger.error("PubSub listen error", error=str(exc))

    async def disconnect(self) -> None:
        if self._redis:
            await self._redis.close()


# ── Global singleton event bus ────────────────────────────────────────────────
event_bus = InMemoryEventBus()
