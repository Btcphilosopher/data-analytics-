"""
AUREUM ANALYTICS — Data Transformation
Normalisation, scaling, encoding, and structural transformations.
All operations are deterministic and replayable.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import (
    MinMaxScaler,
    RobustScaler,
    StandardScaler,
    LabelEncoder,
    OneHotEncoder,
)

from aureum_analytics.config import get_logger

logger = get_logger(__name__)


class Transformer:
    """
    Stateful data transformation engine.

    Scalers and encoders are fit once and stored for
    consistent inference-time transformations.
    """

    def __init__(self) -> None:
        self._scalers: Dict[str, Any] = {}
        self._encoders: Dict[str, Any] = {}

    # ── Scaling ───────────────────────────────────────────────────────────────

    def fit_scaler(
        self,
        df: pd.DataFrame,
        columns: List[str],
        method: str = "standard",
    ) -> "Transformer":
        """
        Fit a scaler to the given columns.
        method: 'standard' | 'minmax' | 'robust'
        """
        scaler_map = {
            "standard": StandardScaler,
            "minmax": MinMaxScaler,
            "robust": RobustScaler,
        }
        if method not in scaler_map:
            raise ValueError(f"Unknown scaler: {method}")

        scaler = scaler_map[method]()
        valid_cols = [c for c in columns if c in df.columns]
        scaler.fit(df[valid_cols].dropna())
        self._scalers[method] = {"scaler": scaler, "columns": valid_cols}
        logger.debug("Scaler fitted", method=method, columns=valid_cols)
        return self

    def transform_scale(
        self,
        df: pd.DataFrame,
        method: str = "standard",
    ) -> pd.DataFrame:
        """Apply a previously fitted scaler."""
        if method not in self._scalers:
            raise RuntimeError(f"Scaler '{method}' not fitted. Call fit_scaler first.")

        scaler_info = self._scalers[method]
        scaler = scaler_info["scaler"]
        columns = scaler_info["columns"]

        df = df.copy()
        df[columns] = scaler.transform(df[columns].fillna(0))
        return df

    def fit_transform_scale(
        self,
        df: pd.DataFrame,
        columns: List[str],
        method: str = "standard",
    ) -> pd.DataFrame:
        """Convenience: fit and transform in one pass."""
        return self.fit_scaler(df, columns, method).transform_scale(df, method)

    # ── Encoding ──────────────────────────────────────────────────────────────

    def label_encode(
        self,
        df: pd.DataFrame,
        columns: List[str],
    ) -> pd.DataFrame:
        """Apply label encoding to categorical columns."""
        df = df.copy()
        for col in columns:
            if col not in df.columns:
                continue
            enc = LabelEncoder()
            df[col] = enc.fit_transform(df[col].astype(str))
            self._encoders[f"label_{col}"] = enc
        return df

    def one_hot_encode(
        self,
        df: pd.DataFrame,
        columns: List[str],
        drop_first: bool = True,
    ) -> pd.DataFrame:
        """Apply one-hot encoding to categorical columns."""
        df = pd.get_dummies(df, columns=columns, drop_first=drop_first)
        logger.debug("One-hot encoding applied", columns=columns)
        return df

    # ── Structural ────────────────────────────────────────────────────────────

    @staticmethod
    def pivot(
        df: pd.DataFrame,
        index: str,
        columns: str,
        values: str,
        aggfunc: str = "mean",
    ) -> pd.DataFrame:
        """Create a pivot table from a DataFrame."""
        pivot_df = pd.pivot_table(
            df,
            index=index,
            columns=columns,
            values=values,
            aggfunc=aggfunc,
        )
        logger.debug("Pivot table created", index=index, columns=columns)
        return pivot_df

    @staticmethod
    def melt(
        df: pd.DataFrame,
        id_vars: List[str],
        value_vars: Optional[List[str]] = None,
        var_name: str = "variable",
        value_name: str = "value",
    ) -> pd.DataFrame:
        """Melt wide format to long format."""
        return pd.melt(
            df,
            id_vars=id_vars,
            value_vars=value_vars,
            var_name=var_name,
            value_name=value_name,
        )

    @staticmethod
    def resample_timeseries(
        df: pd.DataFrame,
        timestamp_col: str,
        frequency: str = "1H",
        agg_func: str = "mean",
    ) -> pd.DataFrame:
        """
        Resample time-series data to a target frequency.
        frequency: pandas offset alias, e.g. '1H', '1D', '5min'
        """
        df = df.copy()
        df[timestamp_col] = pd.to_datetime(df[timestamp_col])
        df = df.set_index(timestamp_col)
        resampled = df.resample(frequency).agg(agg_func)
        logger.debug(
            "Time-series resampled",
            frequency=frequency,
            rows=len(resampled),
        )
        return resampled.reset_index()

    @staticmethod
    def log_transform(
        df: pd.DataFrame,
        columns: List[str],
        base: Optional[float] = None,
        shift: float = 1.0,
    ) -> pd.DataFrame:
        """Apply log transform. Shift avoids log(0)."""
        df = df.copy()
        for col in columns:
            if col in df.columns:
                if base:
                    df[col] = np.log(df[col] + shift) / np.log(base)
                else:
                    df[col] = np.log1p(df[col])
        return df
