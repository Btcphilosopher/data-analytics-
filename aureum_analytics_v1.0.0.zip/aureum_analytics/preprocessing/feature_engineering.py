"""
AUREUM ANALYTICS — Feature Engineering
Time-series features, rolling windows, lag features,
technical indicators, and signal extraction.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from aureum_analytics.config import get_logger

logger = get_logger(__name__)


class FeatureEngineer:
    """
    Feature extraction engine for tabular and time-series data.

    All methods return new DataFrames and append new columns
    without overwriting originals.
    """

    # ── Rolling / Window Features ─────────────────────────────────────────────

    @staticmethod
    def rolling_mean(
        df: pd.DataFrame,
        column: str,
        windows: List[int],
        min_periods: int = 1,
    ) -> pd.DataFrame:
        """Compute rolling means for multiple window sizes."""
        df = df.copy()
        for w in windows:
            df[f"{column}_roll_mean_{w}"] = (
                df[column].rolling(w, min_periods=min_periods).mean()
            )
        return df

    @staticmethod
    def rolling_std(
        df: pd.DataFrame,
        column: str,
        windows: List[int],
        min_periods: int = 1,
    ) -> pd.DataFrame:
        """Compute rolling standard deviation."""
        df = df.copy()
        for w in windows:
            df[f"{column}_roll_std_{w}"] = (
                df[column].rolling(w, min_periods=min_periods).std()
            )
        return df

    @staticmethod
    def rolling_min_max(
        df: pd.DataFrame,
        column: str,
        window: int,
    ) -> pd.DataFrame:
        """Compute rolling min, max, and range."""
        df = df.copy()
        roll = df[column].rolling(window, min_periods=1)
        df[f"{column}_roll_min_{window}"] = roll.min()
        df[f"{column}_roll_max_{window}"] = roll.max()
        df[f"{column}_roll_range_{window}"] = (
            df[f"{column}_roll_max_{window}"] - df[f"{column}_roll_min_{window}"]
        )
        return df

    @staticmethod
    def exponential_weighted_mean(
        df: pd.DataFrame,
        column: str,
        spans: List[int],
    ) -> pd.DataFrame:
        """Compute exponentially weighted moving averages."""
        df = df.copy()
        for span in spans:
            df[f"{column}_ewm_{span}"] = df[column].ewm(span=span).mean()
        return df

    # ── Lag Features ──────────────────────────────────────────────────────────

    @staticmethod
    def lag_features(
        df: pd.DataFrame,
        column: str,
        lags: List[int],
    ) -> pd.DataFrame:
        """Generate lagged versions of a column."""
        df = df.copy()
        for lag in lags:
            df[f"{column}_lag_{lag}"] = df[column].shift(lag)
        return df

    @staticmethod
    def diff_features(
        df: pd.DataFrame,
        column: str,
        periods: List[int] = [1],
    ) -> pd.DataFrame:
        """Generate difference features (returns/deltas)."""
        df = df.copy()
        for p in periods:
            df[f"{column}_diff_{p}"] = df[column].diff(p)
            df[f"{column}_pct_change_{p}"] = df[column].pct_change(p)
        return df

    # ── Calendar / Temporal Features ──────────────────────────────────────────

    @staticmethod
    def temporal_features(
        df: pd.DataFrame,
        timestamp_col: str,
    ) -> pd.DataFrame:
        """Extract calendar features from a datetime column."""
        df = df.copy()
        ts = pd.to_datetime(df[timestamp_col])
        df["hour"] = ts.dt.hour
        df["day_of_week"] = ts.dt.dayofweek
        df["day_of_month"] = ts.dt.day
        df["week_of_year"] = ts.dt.isocalendar().week.astype(int)
        df["month"] = ts.dt.month
        df["quarter"] = ts.dt.quarter
        df["year"] = ts.dt.year
        df["is_weekend"] = (ts.dt.dayofweek >= 5).astype(int)
        df["is_month_start"] = ts.dt.is_month_start.astype(int)
        df["is_month_end"] = ts.dt.is_month_end.astype(int)
        logger.debug("Temporal features extracted", column=timestamp_col)
        return df

    # ── Technical Indicators ──────────────────────────────────────────────────

    @staticmethod
    def bollinger_bands(
        df: pd.DataFrame,
        column: str,
        window: int = 20,
        num_std: float = 2.0,
    ) -> pd.DataFrame:
        """Compute Bollinger Bands for a price series."""
        df = df.copy()
        rolling = df[column].rolling(window=window, min_periods=1)
        df[f"{column}_bb_mid"] = rolling.mean()
        df[f"{column}_bb_std"] = rolling.std()
        df[f"{column}_bb_upper"] = df[f"{column}_bb_mid"] + num_std * df[f"{column}_bb_std"]
        df[f"{column}_bb_lower"] = df[f"{column}_bb_mid"] - num_std * df[f"{column}_bb_std"]
        df[f"{column}_bb_width"] = df[f"{column}_bb_upper"] - df[f"{column}_bb_lower"]
        return df

    @staticmethod
    def rsi(
        df: pd.DataFrame,
        column: str,
        period: int = 14,
    ) -> pd.DataFrame:
        """Compute Relative Strength Index."""
        df = df.copy()
        delta = df[column].diff()
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.rolling(period, min_periods=1).mean()
        avg_loss = loss.rolling(period, min_periods=1).mean()
        rs = avg_gain / avg_loss.replace(0, np.finfo(float).eps)
        df[f"{column}_rsi_{period}"] = 100 - (100 / (1 + rs))
        return df

    @staticmethod
    def macd(
        df: pd.DataFrame,
        column: str,
        fast: int = 12,
        slow: int = 26,
        signal: int = 9,
    ) -> pd.DataFrame:
        """Compute MACD indicator."""
        df = df.copy()
        ema_fast = df[column].ewm(span=fast, adjust=False).mean()
        ema_slow = df[column].ewm(span=slow, adjust=False).mean()
        df[f"{column}_macd"] = ema_fast - ema_slow
        df[f"{column}_macd_signal"] = df[f"{column}_macd"].ewm(span=signal, adjust=False).mean()
        df[f"{column}_macd_hist"] = df[f"{column}_macd"] - df[f"{column}_macd_signal"]
        return df

    # ── Interaction Features ──────────────────────────────────────────────────

    @staticmethod
    def interaction_features(
        df: pd.DataFrame,
        col_a: str,
        col_b: str,
    ) -> pd.DataFrame:
        """Generate cross-column interaction features."""
        df = df.copy()
        df[f"{col_a}_x_{col_b}"] = df[col_a] * df[col_b]
        df[f"{col_a}_div_{col_b}"] = df[col_a] / df[col_b].replace(0, np.finfo(float).eps)
        df[f"{col_a}_minus_{col_b}"] = df[col_a] - df[col_b]
        return df

    @staticmethod
    def zscore_features(
        df: pd.DataFrame,
        columns: List[str],
        window: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Compute z-scores. If window is provided, compute rolling z-score.
        """
        df = df.copy()
        for col in columns:
            if col not in df.columns:
                continue
            if window:
                roll = df[col].rolling(window, min_periods=2)
                df[f"{col}_zscore"] = (df[col] - roll.mean()) / roll.std().replace(0, np.finfo(float).eps)
            else:
                mean = df[col].mean()
                std = df[col].std()
                df[f"{col}_zscore"] = (df[col] - mean) / (std or np.finfo(float).eps)
        return df
