"""
AUREUM ANALYTICS — Data Cleaning
Deterministic, reproducible data cleaning operations.
All transformations are logged, reversible by design, and side-effect free.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from aureum_analytics.config import get_logger

logger = get_logger(__name__)


class CleaningReport(dict):
    """Structured report of applied cleaning operations."""

    def add(self, operation: str, detail: Any) -> None:
        self[operation] = detail


class DataCleaner:
    """
    Stateless data cleaning utility.

    Every method returns a new DataFrame — originals are never mutated.
    All operations produce structured log entries.
    """

    @staticmethod
    def drop_duplicates(
        df: pd.DataFrame,
        subset: Optional[List[str]] = None,
        keep: str = "first",
    ) -> Tuple[pd.DataFrame, int]:
        """Remove duplicate rows. Returns (cleaned_df, dropped_count)."""
        before = len(df)
        df = df.drop_duplicates(subset=subset, keep=keep)
        dropped = before - len(df)
        logger.debug("Duplicates dropped", count=dropped)
        return df, dropped

    @staticmethod
    def handle_nulls(
        df: pd.DataFrame,
        strategy: str = "drop",
        fill_value: Optional[Any] = None,
        columns: Optional[List[str]] = None,
    ) -> Tuple[pd.DataFrame, int]:
        """
        Handle null values.
        strategy: 'drop' | 'fill' | 'ffill' | 'bfill' | 'mean' | 'median' | 'mode'
        """
        cols = columns or df.columns.tolist()
        before_nulls = df[cols].isnull().sum().sum()

        if strategy == "drop":
            df = df.dropna(subset=cols)
        elif strategy == "fill":
            df[cols] = df[cols].fillna(fill_value)
        elif strategy == "ffill":
            df[cols] = df[cols].ffill()
        elif strategy == "bfill":
            df[cols] = df[cols].bfill()
        elif strategy == "mean":
            for col in cols:
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(df[col].mean())
        elif strategy == "median":
            for col in cols:
                if pd.api.types.is_numeric_dtype(df[col]):
                    df[col] = df[col].fillna(df[col].median())
        elif strategy == "mode":
            for col in cols:
                mode_val = df[col].mode()
                if not mode_val.empty:
                    df[col] = df[col].fillna(mode_val[0])
        else:
            raise ValueError(f"Unknown null strategy: {strategy}")

        after_nulls = df[cols].isnull().sum().sum()
        resolved = int(before_nulls - after_nulls)
        logger.debug("Nulls handled", strategy=strategy, resolved=resolved)
        return df, resolved

    @staticmethod
    def remove_outliers(
        df: pd.DataFrame,
        columns: List[str],
        method: str = "iqr",
        factor: float = 1.5,
        z_threshold: float = 3.0,
    ) -> Tuple[pd.DataFrame, int]:
        """
        Remove outliers from numeric columns.
        method: 'iqr' | 'zscore'
        """
        before = len(df)
        mask = pd.Series([True] * len(df), index=df.index)

        for col in columns:
            if col not in df.columns or not pd.api.types.is_numeric_dtype(df[col]):
                continue

            if method == "iqr":
                q1 = df[col].quantile(0.25)
                q3 = df[col].quantile(0.75)
                iqr = q3 - q1
                lower = q1 - factor * iqr
                upper = q3 + factor * iqr
                mask &= df[col].between(lower, upper)

            elif method == "zscore":
                z_scores = (df[col] - df[col].mean()) / df[col].std()
                mask &= z_scores.abs() <= z_threshold

        df = df[mask]
        removed = before - len(df)
        logger.debug(
            "Outliers removed",
            columns=columns,
            method=method,
            count=removed,
        )
        return df, removed

    @staticmethod
    def enforce_dtypes(
        df: pd.DataFrame,
        schema: Dict[str, str],
    ) -> Tuple[pd.DataFrame, List[str]]:
        """
        Coerce columns to specified types. Returns (df, list of failed columns).
        """
        failed: List[str] = []
        for col, dtype in schema.items():
            if col not in df.columns:
                continue
            try:
                if dtype == "datetime":
                    df[col] = pd.to_datetime(df[col], errors="coerce")
                elif dtype in ("float", "int"):
                    df[col] = pd.to_numeric(df[col], errors="coerce")
                else:
                    df[col] = df[col].astype(dtype)
            except Exception as exc:
                failed.append(col)
                logger.warning("Dtype coercion failed", column=col, dtype=dtype, error=str(exc))

        return df, failed

    @staticmethod
    def clip_values(
        df: pd.DataFrame,
        columns: List[str],
        lower: Optional[float] = None,
        upper: Optional[float] = None,
    ) -> pd.DataFrame:
        """Clip numeric column values to [lower, upper] range."""
        for col in columns:
            if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].clip(lower=lower, upper=upper)
        return df

    @classmethod
    def clean(
        cls,
        df: pd.DataFrame,
        drop_dups: bool = True,
        null_strategy: str = "drop",
        outlier_columns: Optional[List[str]] = None,
        dtype_schema: Optional[Dict[str, str]] = None,
    ) -> Tuple[pd.DataFrame, CleaningReport]:
        """
        Apply a full cleaning pipeline.
        Returns (cleaned_df, report).
        """
        report = CleaningReport()
        original_len = len(df)

        if drop_dups:
            df, dropped = cls.drop_duplicates(df)
            report.add("duplicates_dropped", dropped)

        df, resolved = cls.handle_nulls(df, strategy=null_strategy)
        report.add("nulls_resolved", resolved)

        if outlier_columns:
            df, removed = cls.remove_outliers(df, outlier_columns)
            report.add("outliers_removed", removed)

        if dtype_schema:
            df, failed_cols = cls.enforce_dtypes(df, dtype_schema)
            report.add("dtype_coercion_failures", failed_cols)

        report.add("rows_before", original_len)
        report.add("rows_after", len(df))
        report.add("retention_rate", f"{len(df)/max(original_len, 1):.2%}")

        logger.info(
            "Cleaning complete",
            rows_before=original_len,
            rows_after=len(df),
        )
        return df, report
