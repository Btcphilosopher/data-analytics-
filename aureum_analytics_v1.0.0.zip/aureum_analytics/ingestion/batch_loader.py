"""
AUREUM ANALYTICS — Batch Loader
Orchestrates large-scale batch ingestion from multiple sources
with validation, deduplication, and load tracking.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

import pandas as pd
from pydantic import BaseModel

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class BatchManifest(BaseModel):
    """Record of a completed batch ingestion run."""

    batch_id: str
    source_name: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    total_records: int = 0
    accepted_records: int = 0
    rejected_records: int = 0
    status: str = "pending"  # pending | running | complete | failed
    error: Optional[str] = None


class SchemaValidator:
    """Lightweight schema enforcement for ingested DataFrames."""

    def __init__(
        self,
        required_columns: List[str],
        dtypes: Optional[Dict[str, str]] = None,
        max_null_ratio: float = 0.5,
    ) -> None:
        self.required_columns = required_columns
        self.dtypes = dtypes or {}
        self.max_null_ratio = max_null_ratio

    def validate(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
        """
        Validate and coerce a DataFrame against schema rules.
        Returns (valid_df, list_of_violations).
        """
        violations: List[str] = []

        # Required column check
        missing = set(self.required_columns) - set(df.columns)
        if missing:
            violations.append(f"Missing required columns: {missing}")
            return df.iloc[0:0], violations  # empty frame

        # Null ratio check
        for col in self.required_columns:
            null_ratio = df[col].isnull().mean()
            if null_ratio > self.max_null_ratio:
                violations.append(
                    f"Column '{col}' exceeds null ratio: {null_ratio:.2%}"
                )

        # Type coercion
        for col, dtype in self.dtypes.items():
            if col in df.columns:
                try:
                    if dtype == "datetime":
                        df[col] = pd.to_datetime(df[col], errors="coerce")
                    elif dtype == "numeric":
                        df[col] = pd.to_numeric(df[col], errors="coerce")
                    else:
                        df[col] = df[col].astype(dtype)
                except Exception as exc:
                    violations.append(f"Type coercion failed for '{col}': {exc}")

        return df, violations


class BatchLoader:
    """
    Orchestrates batch ingestion with schema validation, deduplication,
    and structured manifests.
    """

    def __init__(
        self,
        source_name: str,
        validator: Optional[SchemaValidator] = None,
        dedup_columns: Optional[List[str]] = None,
    ) -> None:
        self.source_name = source_name
        self.validator = validator
        self.dedup_columns = dedup_columns
        self._manifests: List[BatchManifest] = []

    def _generate_batch_id(self) -> str:
        ts = datetime.now(timezone.utc).isoformat()
        return hashlib.sha256(f"{self.source_name}:{ts}".encode()).hexdigest()[:16]

    def _deduplicate(self, df: pd.DataFrame) -> pd.DataFrame:
        if not self.dedup_columns:
            return df
        before = len(df)
        df = df.drop_duplicates(subset=self.dedup_columns)
        dropped = before - len(df)
        if dropped:
            logger.debug(
                "Duplicates removed",
                source=self.source_name,
                count=dropped,
            )
        return df

    def load(
        self,
        df: pd.DataFrame,
        downstream: Optional[Callable[[pd.DataFrame], None]] = None,
    ) -> BatchManifest:
        """
        Validate, deduplicate, and load a DataFrame batch.
        Optionally dispatches to a downstream processor.
        """
        batch_id = self._generate_batch_id()
        manifest = BatchManifest(
            batch_id=batch_id,
            source_name=self.source_name,
            started_at=datetime.now(timezone.utc),
            total_records=len(df),
            status="running",
        )

        try:
            # Validate
            if self.validator:
                df, violations = self.validator.validate(df)
                if violations:
                    logger.warning(
                        "Schema violations detected",
                        batch_id=batch_id,
                        violations=violations,
                    )

            # Deduplicate
            df = self._deduplicate(df)

            manifest.accepted_records = len(df)
            manifest.rejected_records = manifest.total_records - len(df)

            # Dispatch downstream
            if downstream and len(df) > 0:
                downstream(df)

            manifest.status = "complete"
            manifest.completed_at = datetime.now(timezone.utc)

            logger.info(
                "Batch load complete",
                batch_id=batch_id,
                source=self.source_name,
                accepted=manifest.accepted_records,
                rejected=manifest.rejected_records,
            )

        except Exception as exc:
            manifest.status = "failed"
            manifest.error = str(exc)
            manifest.completed_at = datetime.now(timezone.utc)
            logger.error(
                "Batch load failed",
                batch_id=batch_id,
                source=self.source_name,
                error=str(exc),
            )
            raise

        finally:
            self._manifests.append(manifest)

        return manifest

    def get_manifests(self) -> List[BatchManifest]:
        """Return all load manifests for audit trail."""
        return self._manifests
