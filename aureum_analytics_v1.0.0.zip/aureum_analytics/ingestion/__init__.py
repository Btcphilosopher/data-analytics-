"""AUREUM ANALYTICS — Ingestion Layer."""

from .stream_handler import StreamHandler, StreamRecord
from .batch_loader import BatchLoader, BatchManifest, SchemaValidator
from .connectors import (
    RESTConnector, RESTConnectorConfig,
    FileConnector, FileConnectorConfig,
    DatabaseConnector, DatabaseConnectorConfig,
)

__all__ = [
    "StreamHandler", "StreamRecord",
    "BatchLoader", "BatchManifest", "SchemaValidator",
    "RESTConnector", "RESTConnectorConfig",
    "FileConnector", "FileConnectorConfig",
    "DatabaseConnector", "DatabaseConnectorConfig",
]
