"""
AUREUM ANALYTICS — Database Connector
Async SQLAlchemy-based connector for PostgreSQL / TimescaleDB ingestion.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class DatabaseConnectorConfig(BaseModel):
    """Configuration contract for a database ingestion source."""

    name: str
    connection_url: Optional[str] = None  # defaults to settings.DATABASE_URL
    query: str
    params: Dict[str, Any] = Field(default_factory=dict)
    chunk_size: int = settings.INGESTION_BATCH_SIZE
    timeout: float = settings.INGESTION_TIMEOUT


class DatabaseConnector:
    """
    Async PostgreSQL connector for structured query-based ingestion.

    Supports:
    - parameterised SQL queries
    - chunked result sets
    - automatic session lifecycle management
    """

    def __init__(self, config: DatabaseConnectorConfig) -> None:
        self.config = config
        url = config.connection_url or settings.DATABASE_URL
        self._engine = create_async_engine(
            url,
            pool_size=5,
            max_overflow=10,
            echo=settings.DEBUG,
        )
        self._session_factory = sessionmaker(
            self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

    async def fetch(self) -> pd.DataFrame:
        """Execute configured query and return results as DataFrame."""
        async with self._session_factory() as session:
            try:
                result = await session.execute(
                    text(self.config.query),
                    self.config.params,
                )
                rows = result.fetchall()
                columns = list(result.keys())
                df = pd.DataFrame(rows, columns=columns)
                logger.info(
                    "Database query complete",
                    connector=self.config.name,
                    rows=len(df),
                    columns=columns,
                )
                return df
            except Exception as exc:
                logger.error(
                    "Database query failed",
                    connector=self.config.name,
                    error=str(exc),
                )
                raise

    async def fetch_chunks(self):
        """Yield chunked query results for large result sets."""
        df = await self.fetch()
        for start in range(0, len(df), self.config.chunk_size):
            yield df.iloc[start : start + self.config.chunk_size]

    async def to_records(self) -> List[Dict[str, Any]]:
        """Return query results as list of dicts."""
        df = await self.fetch()
        return df.to_dict(orient="records")

    async def close(self) -> None:
        """Dispose of connection pool."""
        await self._engine.dispose()
        logger.info("Database connector closed", connector=self.config.name)
