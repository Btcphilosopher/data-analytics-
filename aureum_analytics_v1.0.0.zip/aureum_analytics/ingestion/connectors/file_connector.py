"""
AUREUM ANALYTICS — File & CSV Connector
Ingests structured data from flat files with schema validation
and configurable parsing behaviour.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
from pydantic import BaseModel, Field

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class FileConnectorConfig(BaseModel):
    """Configuration contract for a file-based ingestion source."""

    name: str
    path: str
    file_format: str = "csv"  # csv | json | parquet | excel
    delimiter: str = ","
    encoding: str = "utf-8"
    chunk_size: int = settings.INGESTION_BATCH_SIZE
    date_columns: List[str] = Field(default_factory=list)
    numeric_columns: List[str] = Field(default_factory=list)
    drop_nulls: bool = False
    rename_columns: Dict[str, str] = Field(default_factory=dict)


class FileConnector:
    """
    File-based data connector supporting CSV, JSON, Parquet, and Excel.

    Yields data in configurable chunk sizes for memory-efficient ingestion.
    Applies column type coercion and rename mappings on load.
    """

    SUPPORTED_FORMATS = {"csv", "json", "parquet", "excel", "xlsx"}

    def __init__(self, config: FileConnectorConfig) -> None:
        self.config = config
        self._path = Path(config.path)

    def _validate_path(self) -> None:
        if not self._path.exists():
            raise FileNotFoundError(
                f"[{self.config.name}] Source file not found: {self._path}"
            )
        if self.config.file_format not in self.SUPPORTED_FORMATS:
            raise ValueError(
                f"[{self.config.name}] Unsupported format: {self.config.file_format}"
            )

    def _apply_transforms(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply configured column transforms."""
        if self.config.rename_columns:
            df = df.rename(columns=self.config.rename_columns)

        for col in self.config.date_columns:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")

        for col in self.config.numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")

        if self.config.drop_nulls:
            df = df.dropna()

        return df

    def load_all(self) -> pd.DataFrame:
        """Load the entire file into a DataFrame."""
        self._validate_path()
        fmt = self.config.file_format.lower()

        if fmt == "csv":
            df = pd.read_csv(
                self._path,
                delimiter=self.config.delimiter,
                encoding=self.config.encoding,
            )
        elif fmt == "json":
            df = pd.read_json(self._path, encoding=self.config.encoding)
        elif fmt == "parquet":
            df = pd.read_parquet(self._path)
        elif fmt in ("excel", "xlsx"):
            df = pd.read_excel(self._path)
        else:
            raise ValueError(f"Unsupported format: {fmt}")

        df = self._apply_transforms(df)
        logger.info(
            "File loaded",
            connector=self.config.name,
            rows=len(df),
            columns=list(df.columns),
        )
        return df

    def stream_chunks(self):
        """Yield DataFrame chunks for memory-efficient batch ingestion."""
        self._validate_path()
        fmt = self.config.file_format.lower()

        if fmt == "csv":
            reader = pd.read_csv(
                self._path,
                delimiter=self.config.delimiter,
                encoding=self.config.encoding,
                chunksize=self.config.chunk_size,
            )
            for i, chunk in enumerate(reader):
                chunk = self._apply_transforms(chunk)
                logger.debug(
                    "File chunk streamed",
                    connector=self.config.name,
                    chunk=i,
                    rows=len(chunk),
                )
                yield chunk
        else:
            # Non-chunked formats: load then slice
            df = self.load_all()
            for start in range(0, len(df), self.config.chunk_size):
                yield df.iloc[start : start + self.config.chunk_size]

    def to_records(self) -> List[Dict[str, Any]]:
        """Return full file content as list of dicts."""
        return self.load_all().to_dict(orient="records")
