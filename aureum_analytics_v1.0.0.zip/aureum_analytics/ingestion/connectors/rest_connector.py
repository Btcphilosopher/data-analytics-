"""
AUREUM ANALYTICS — REST API Connector
Ingests data from HTTP/REST endpoints with schema validation,
retry logic, and rate control.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, Iterator, List, Optional

import httpx
from pydantic import BaseModel, Field, HttpUrl

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class RESTConnectorConfig(BaseModel):
    """Configuration contract for a REST ingestion source."""

    name: str
    base_url: str
    endpoint: str
    method: str = "GET"
    headers: Dict[str, str] = Field(default_factory=dict)
    params: Dict[str, Any] = Field(default_factory=dict)
    body: Optional[Dict[str, Any]] = None
    timeout: float = settings.INGESTION_TIMEOUT
    max_retries: int = settings.INGESTION_MAX_RETRIES
    rate_limit_rps: float = 10.0  # requests per second
    auth_token: Optional[str] = None


class RESTConnector:
    """
    Async REST API data connector.

    Supports:
    - configurable HTTP method, headers, and parameters
    - exponential backoff retry
    - per-connector rate limiting
    - optional Bearer token authentication
    """

    def __init__(self, config: RESTConnectorConfig) -> None:
        self.config = config
        self._last_request_time: float = 0.0
        self._min_interval: float = 1.0 / max(config.rate_limit_rps, 0.001)

    @property
    def _headers(self) -> Dict[str, str]:
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            **self.config.headers,
        }
        if self.config.auth_token:
            headers["Authorization"] = f"Bearer {self.config.auth_token}"
        return headers

    async def _rate_limit(self) -> None:
        """Enforce per-connector rate limiting."""
        elapsed = time.monotonic() - self._last_request_time
        if elapsed < self._min_interval:
            await asyncio.sleep(self._min_interval - elapsed)
        self._last_request_time = time.monotonic()

    async def fetch(self) -> List[Dict[str, Any]]:
        """
        Execute the configured request and return parsed JSON payload.
        Retries with exponential backoff on transient failures.
        """
        url = f"{self.config.base_url.rstrip('/')}/{self.config.endpoint.lstrip('/')}"

        for attempt in range(1, self.config.max_retries + 1):
            await self._rate_limit()
            try:
                async with httpx.AsyncClient(timeout=self.config.timeout) as client:
                    response = await client.request(
                        method=self.config.method,
                        url=url,
                        headers=self._headers,
                        params=self.config.params if self.config.method == "GET" else None,
                        json=self.config.body if self.config.method != "GET" else None,
                    )
                    response.raise_for_status()
                    payload = response.json()
                    records = payload if isinstance(payload, list) else [payload]
                    logger.info(
                        "REST fetch complete",
                        connector=self.config.name,
                        url=url,
                        records=len(records),
                    )
                    return records

            except httpx.HTTPStatusError as exc:
                logger.warning(
                    "HTTP error on REST fetch",
                    connector=self.config.name,
                    status=exc.response.status_code,
                    attempt=attempt,
                )
                if exc.response.status_code < 500:
                    raise
            except httpx.RequestError as exc:
                logger.warning(
                    "Request error on REST fetch",
                    connector=self.config.name,
                    error=str(exc),
                    attempt=attempt,
                )

            if attempt < self.config.max_retries:
                backoff = 2 ** attempt
                logger.debug("Retrying after backoff", seconds=backoff)
                await asyncio.sleep(backoff)

        raise RuntimeError(
            f"[{self.config.name}] Failed after {self.config.max_retries} attempts"
        )

    async def stream(self, interval: float = 5.0) -> Iterator[List[Dict[str, Any]]]:
        """
        Continuously poll the endpoint and yield batches.
        For simulated streaming from REST APIs.
        """
        logger.info(
            "Starting REST stream poll",
            connector=self.config.name,
            interval=interval,
        )
        while True:
            try:
                batch = await self.fetch()
                yield batch
            except Exception as exc:
                logger.error(
                    "Stream fetch error",
                    connector=self.config.name,
                    error=str(exc),
                )
            await asyncio.sleep(interval)
