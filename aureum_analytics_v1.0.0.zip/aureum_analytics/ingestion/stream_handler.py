"""
AUREUM ANALYTICS — Stream Handler
Manages real-time async data ingestion pipelines with buffering,
back-pressure, and structured event emission.
"""

from __future__ import annotations

import asyncio
from collections import deque
from datetime import datetime, timezone
from typing import Any, Callable, Deque, Dict, List, Optional

from pydantic import BaseModel

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class StreamRecord(BaseModel):
    """Normalised record envelope for all streamed data."""

    source: str
    timestamp: datetime
    payload: Dict[str, Any]
    schema_version: str = "1.0"
    ingestion_id: Optional[str] = None


class StreamHandler:
    """
    Async stream handler with internal buffer and configurable flush strategy.

    Architecture:
    - Producer coroutine pushes records to the internal deque buffer
    - Consumer coroutine flushes batches to registered downstream handlers
    - Back-pressure is enforced via buffer capacity limits
    """

    def __init__(
        self,
        source_name: str,
        buffer_size: int = settings.STREAM_BUFFER_SIZE,
        flush_interval: float = settings.STREAM_FLUSH_INTERVAL,
    ) -> None:
        self.source_name = source_name
        self.buffer_size = buffer_size
        self.flush_interval = flush_interval
        self._buffer: Deque[StreamRecord] = deque(maxlen=buffer_size)
        self._handlers: List[Callable[[List[StreamRecord]], Any]] = []
        self._running = False
        self._stats = {
            "total_received": 0,
            "total_flushed": 0,
            "total_dropped": 0,
            "flushes": 0,
        }

    def register_handler(
        self, handler: Callable[[List[StreamRecord]], Any]
    ) -> None:
        """Register a downstream flush handler."""
        self._handlers.append(handler)
        logger.debug(
            "Handler registered",
            source=self.source_name,
            handler=handler.__name__,
        )

    def push(self, payload: Dict[str, Any]) -> bool:
        """
        Push a raw payload into the stream buffer.
        Returns False if buffer is at capacity (record dropped).
        """
        if len(self._buffer) >= self.buffer_size:
            self._stats["total_dropped"] += 1
            logger.warning(
                "Buffer full — record dropped",
                source=self.source_name,
                buffer_size=self.buffer_size,
            )
            return False

        record = StreamRecord(
            source=self.source_name,
            timestamp=datetime.now(timezone.utc),
            payload=payload,
        )
        self._buffer.append(record)
        self._stats["total_received"] += 1
        return True

    def push_batch(self, payloads: List[Dict[str, Any]]) -> int:
        """Push multiple records. Returns count of accepted records."""
        return sum(1 for p in payloads if self.push(p))

    async def _flush(self) -> None:
        """Drain buffer and dispatch to registered handlers."""
        if not self._buffer:
            return

        batch: List[StreamRecord] = []
        while self._buffer:
            batch.append(self._buffer.popleft())

        self._stats["total_flushed"] += len(batch)
        self._stats["flushes"] += 1

        logger.debug(
            "Flushing batch",
            source=self.source_name,
            batch_size=len(batch),
            flush_count=self._stats["flushes"],
        )

        for handler in self._handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(batch)
                else:
                    handler(batch)
            except Exception as exc:
                logger.error(
                    "Handler error during flush",
                    source=self.source_name,
                    handler=handler.__name__,
                    error=str(exc),
                )

    async def run(self) -> None:
        """Run the continuous flush loop."""
        self._running = True
        logger.info("Stream handler started", source=self.source_name)

        while self._running:
            await asyncio.sleep(self.flush_interval)
            await self._flush()

        # Final flush on stop
        await self._flush()
        logger.info("Stream handler stopped", source=self.source_name)

    async def stop(self) -> None:
        """Gracefully stop the stream handler."""
        self._running = False

    def get_stats(self) -> Dict[str, Any]:
        """Return current handler statistics."""
        return {
            **self._stats,
            "buffer_occupancy": len(self._buffer),
            "buffer_capacity": self.buffer_size,
        }
