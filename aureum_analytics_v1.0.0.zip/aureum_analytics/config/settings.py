"""
AUREUM ANALYTICS — Configuration & Settings
Centralised settings management via Pydantic BaseSettings.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class AureumSettings(BaseSettings):
    """Primary configuration manifest for AUREUM ANALYTICS."""

    # ── Identity ──────────────────────────────────────────────────────────────
    APP_NAME: str = "AUREUM ANALYTICS"
    APP_VERSION: str = "1.0.0"
    APP_ENV: str = Field(default="development", alias="AUREUM_ENV")
    DEBUG: bool = Field(default=False, alias="AUREUM_DEBUG")

    # ── Security ──────────────────────────────────────────────────────────────
    SECRET_KEY: str = Field(
        default="aureum-sovereign-key-change-in-production",
        alias="AUREUM_SECRET_KEY",
    )
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRY_MINUTES: int = 60
    API_RATE_LIMIT: int = 100  # requests per minute

    # ── Database ──────────────────────────────────────────────────────────────
    DATABASE_URL: str = Field(
        default="postgresql+asyncpg://aureum:aureum@localhost:5432/aureum_db",
        alias="DATABASE_URL",
    )
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20

    # ── Redis ─────────────────────────────────────────────────────────────────
    REDIS_URL: str = Field(
        default="redis://localhost:6379/0",
        alias="REDIS_URL",
    )
    REDIS_CACHE_TTL: int = 300  # seconds

    # ── ML / Modelling ────────────────────────────────────────────────────────
    MODEL_REGISTRY_PATH: str = Field(
        default="./model_registry",
        alias="MODEL_REGISTRY_PATH",
    )
    ANOMALY_THRESHOLD: float = 0.05
    FORECAST_HORIZON: int = 30  # days

    # ── Streaming ─────────────────────────────────────────────────────────────
    STREAM_BUFFER_SIZE: int = 1000
    STREAM_FLUSH_INTERVAL: float = 1.0  # seconds
    EVENT_BUS_CHANNEL: str = "aureum:events"

    # ── Alerting ──────────────────────────────────────────────────────────────
    ALERT_CHANNEL: str = "aureum:alerts"
    ALERT_PRIORITY_HIGH_THRESHOLD: float = 0.9
    ALERT_PRIORITY_MEDIUM_THRESHOLD: float = 0.6

    # ── Dashboard ─────────────────────────────────────────────────────────────
    DASHBOARD_HOST: str = "0.0.0.0"
    DASHBOARD_PORT: int = 8050
    DASHBOARD_REFRESH_INTERVAL: int = 2000  # milliseconds

    # ── API ───────────────────────────────────────────────────────────────────
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8050"]

    # ── Ingestion ─────────────────────────────────────────────────────────────
    INGESTION_BATCH_SIZE: int = 500
    INGESTION_MAX_RETRIES: int = 3
    INGESTION_TIMEOUT: float = 30.0

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "ignore"


@lru_cache(maxsize=1)
def get_settings() -> AureumSettings:
    """Return singleton settings instance."""
    return AureumSettings()


settings = get_settings()
