"""
AUREUM ANALYTICS — Platform Entry Point
Launches the API server, dashboard, or combined runtime.
Configures logging and wires all platform components.

Usage:
    python -m aureum_analytics.main api        # FastAPI only
    python -m aureum_analytics.main dashboard  # Dash dashboard only
    python -m aureum_analytics.main all        # Both concurrently
    python -m aureum_analytics.main demo       # Run demo pipeline
"""

from __future__ import annotations

import asyncio
import sys
from typing import Optional

from aureum_analytics.config import configure_logging, get_logger, settings

logger = get_logger(__name__)


def start_api() -> None:
    """Launch the FastAPI server via uvicorn."""
    import uvicorn
    configure_logging(level="DEBUG" if settings.DEBUG else "INFO")
    logger.info(
        "Starting AUREUM API",
        host=settings.API_HOST,
        port=settings.API_PORT,
    )
    uvicorn.run(
        "aureum_analytics.api.app:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.DEBUG,
        log_level="debug" if settings.DEBUG else "info",
    )


def start_dashboard() -> None:
    """Launch the Plotly Dash dashboard."""
    configure_logging(level="INFO")
    logger.info(
        "Starting AUREUM Dashboard",
        host=settings.DASHBOARD_HOST,
        port=settings.DASHBOARD_PORT,
    )
    from aureum_analytics.dashboard.app import run_dashboard
    run_dashboard()


async def run_demo_pipeline() -> None:
    """
    Execute a complete end-to-end demonstration pipeline:
    Mock data → Preprocessing → ML → Anomaly detection → Alerts
    """
    configure_logging(level="INFO")
    logger.info("=" * 60)
    logger.info("AUREUM ANALYTICS — DEMO PIPELINE")
    logger.info("=" * 60)

    # 1. Generate mock financial data
    from aureum_analytics.mock.data_generator import MockDataGenerator
    df = MockDataGenerator.financial_timeseries(n_days=180)
    logger.info("Mock data generated", rows=len(df))

    # 2. Run preprocessing pipeline
    from aureum_analytics.pipelines.config_loader import ConfigLoader
    pipeline = ConfigLoader.from_file(
        "aureum_analytics/pipelines/configs/financial_pipeline.yaml"
    )
    processed_df, report = await pipeline.run(df)
    logger.info("Pipeline complete", summary=report.summary())

    # 3. Anomaly detection
    from aureum_analytics.ml.models.anomaly import ZScoreAnomalyDetector
    detector = ZScoreAnomalyDetector(threshold=2.5)
    anomaly_df = detector.detect(processed_df, columns=["close"])
    n_anomalies = int(anomaly_df["is_anomaly"].sum())
    logger.info("Anomaly scan complete", anomalies=n_anomalies)

    # 4. Train forecaster
    from aureum_analytics.ml.models.forecasting import XGBoostForecaster
    forecaster = XGBoostForecaster(n_lags=14, horizon=30)
    forecaster.fit(pd.DataFrame(), y=df["close"])
    result = forecaster.forecast(steps=30, freq="D")
    df_forecast = result.to_dataframe()
    logger.info(
        "Forecast generated",
        steps=30,
        mean=f"{df_forecast['forecast'].mean():.2f}",
    )

    # 5. Raise anomaly alerts
    from aureum_analytics.alerts.alert_engine import alert_engine
    alerts = await alert_engine.raise_anomaly_alerts(
        anomaly_df,
        source="demo_pipeline",
        value_col="close",
    )
    logger.info("Alerts raised", count=len(alerts))

    logger.info("=" * 60)
    logger.info("DEMO COMPLETE")
    logger.info("=" * 60)


import pandas as pd  # needed in async demo scope


def main() -> None:
    mode = sys.argv[1] if len(sys.argv) > 1 else "api"

    if mode == "api":
        start_api()
    elif mode == "dashboard":
        start_dashboard()
    elif mode == "all":
        import threading
        t = threading.Thread(target=start_api, daemon=True)
        t.start()
        start_dashboard()
    elif mode == "demo":
        asyncio.run(run_demo_pipeline())
    else:
        print(f"Unknown mode: {mode}")
        print("Usage: python -m aureum_analytics.main [api|dashboard|all|demo]")
        sys.exit(1)


if __name__ == "__main__":
    main()
