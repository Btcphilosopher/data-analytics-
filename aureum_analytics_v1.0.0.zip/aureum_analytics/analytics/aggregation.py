"""
AUREUM ANALYTICS — Analytics Engine
Aggregation, cohort analysis, KPI metrics, trend analysis,
and pivot operations. All methods are stateless and composable.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd

from aureum_analytics.config import get_logger

logger = get_logger(__name__)


class AggregationEngine:
    """
    Flexible multi-dimensional aggregation engine.
    """

    @staticmethod
    def group_aggregate(
        df: pd.DataFrame,
        group_by: Union[str, List[str]],
        metrics: Dict[str, Union[str, List[str]]],
    ) -> pd.DataFrame:
        """
        Group and aggregate with named metric configurations.

        Args:
            group_by: column(s) to group by
            metrics: {column: agg_func} or {column: [agg1, agg2]}
        """
        result = df.groupby(group_by).agg(metrics)
        result.columns = [
            "_".join(filter(None, col)).strip()
            if isinstance(col, tuple) else col
            for col in result.columns
        ]
        return result.reset_index()

    @staticmethod
    def time_bucket(
        df: pd.DataFrame,
        timestamp_col: str,
        bucket: str,
        value_col: str,
        agg_func: str = "sum",
    ) -> pd.DataFrame:
        """Aggregate a metric into time buckets (e.g. '1H', '1D', '1W')."""
        df = df.copy()
        df[timestamp_col] = pd.to_datetime(df[timestamp_col])
        df = df.set_index(timestamp_col)
        return df[value_col].resample(bucket).agg(agg_func).reset_index()

    @staticmethod
    def cumulative(
        df: pd.DataFrame,
        value_col: str,
        group_col: Optional[str] = None,
    ) -> pd.DataFrame:
        """Add cumulative sum column."""
        df = df.copy()
        if group_col:
            df[f"{value_col}_cumsum"] = df.groupby(group_col)[value_col].cumsum()
        else:
            df[f"{value_col}_cumsum"] = df[value_col].cumsum()
        return df

    @staticmethod
    def pivot_table(
        df: pd.DataFrame,
        index: Union[str, List[str]],
        columns: str,
        values: str,
        aggfunc: str = "sum",
        fill_value: float = 0.0,
    ) -> pd.DataFrame:
        """Construct a pivot table."""
        return pd.pivot_table(
            df,
            index=index,
            columns=columns,
            values=values,
            aggfunc=aggfunc,
            fill_value=fill_value,
        ).reset_index()


class CohortAnalyser:
    """
    Retention and conversion cohort analysis.
    """

    @staticmethod
    def retention_matrix(
        df: pd.DataFrame,
        user_col: str,
        event_date_col: str,
        cohort_period: str = "M",
    ) -> pd.DataFrame:
        """
        Compute user retention matrix.

        Returns a DataFrame where:
        - rows = cohort periods (acquisition month/week)
        - columns = periods since acquisition
        - values = retention rate
        """
        df = df.copy()
        df[event_date_col] = pd.to_datetime(df[event_date_col])
        df["period"] = df[event_date_col].dt.to_period(cohort_period)

        # Determine cohort (first event period per user)
        cohort_df = (
            df.groupby(user_col)[event_date_col]
            .min()
            .reset_index()
            .rename(columns={event_date_col: "cohort_date"})
        )
        cohort_df["cohort"] = pd.to_datetime(cohort_df["cohort_date"]).dt.to_period(cohort_period)

        merged = df.merge(cohort_df[[user_col, "cohort"]], on=user_col)
        merged["period_number"] = (
            merged["period"].astype(int) - merged["cohort"].astype(int)
        )

        cohort_sizes = merged.groupby("cohort")[user_col].nunique()
        cohort_data = merged.groupby(["cohort", "period_number"])[user_col].nunique()
        retention = cohort_data.div(cohort_sizes, level="cohort").unstack()
        logger.info("Retention matrix computed", cohorts=len(retention))
        return retention

    @staticmethod
    def conversion_funnel(
        df: pd.DataFrame,
        stage_col: str,
        count_col: str,
        stages: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """
        Compute conversion rates between funnel stages.
        """
        if stages:
            df = df[df[stage_col].isin(stages)]
            df = df.set_index(stage_col).loc[stages].reset_index()

        totals = df.groupby(stage_col)[count_col].sum()
        if stages:
            totals = totals.reindex(stages)

        first_value = totals.iloc[0] if len(totals) else 1
        result = pd.DataFrame({
            "stage": totals.index,
            "count": totals.values,
            "rate_from_top": totals.values / max(first_value, 1),
            "step_conversion": totals.values / np.roll(totals.values, 1),
        })
        result.loc[0, "step_conversion"] = 1.0
        return result


class MetricsCalculator:
    """
    Standard business and operational KPI calculations.
    """

    @staticmethod
    def moving_average(
        series: pd.Series,
        window: int,
        center: bool = False,
    ) -> pd.Series:
        return series.rolling(window=window, center=center).mean()

    @staticmethod
    def year_over_year(
        df: pd.DataFrame,
        date_col: str,
        value_col: str,
    ) -> pd.DataFrame:
        """Compute year-over-year change."""
        df = df.copy()
        df[date_col] = pd.to_datetime(df[date_col])
        df = df.set_index(date_col).sort_index()
        df["yoy_change"] = df[value_col].pct_change(periods=365)
        return df.reset_index()

    @staticmethod
    def trend_direction(
        series: pd.Series,
        window: int = 7,
    ) -> pd.Series:
        """
        Classify local trend as 'up', 'down', or 'flat'
        based on rolling linear regression slope.
        """
        from scipy.stats import linregress

        results = []
        half = window // 2
        for i in range(len(series)):
            start = max(0, i - window + 1)
            subset = series.iloc[start : i + 1]
            if len(subset) < 3:
                results.append("flat")
                continue
            x = np.arange(len(subset))
            slope, _, _, _, _ = linregress(x, subset.values)
            if slope > 0.01:
                results.append("up")
            elif slope < -0.01:
                results.append("down")
            else:
                results.append("flat")

        return pd.Series(results, index=series.index)

    @staticmethod
    def summary_stats(
        df: pd.DataFrame,
        columns: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """Compute comprehensive summary statistics."""
        cols = columns or df.select_dtypes(include="number").columns.tolist()
        stats = df[cols].agg([
            "mean", "median", "std", "min", "max",
            lambda x: x.quantile(0.25),
            lambda x: x.quantile(0.75),
        ])
        stats.index = ["mean", "median", "std", "min", "max", "q25", "q75"]
        return stats.T
