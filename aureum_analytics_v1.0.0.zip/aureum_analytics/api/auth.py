"""
AUREUM ANALYTICS — API Authentication
JWT-based authentication with role-based access control
and rate limiting enforcement.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)
bearer_scheme = HTTPBearer()


# ── Models ────────────────────────────────────────────────────────────────────

class TokenPayload(BaseModel):
    sub: str
    role: str
    exp: datetime
    iat: datetime


class UserContext(BaseModel):
    user_id: str
    role: str
    permissions: List[str]


ROLE_PERMISSIONS: Dict[str, List[str]] = {
    "admin": ["read", "write", "predict", "delete", "admin"],
    "analyst": ["read", "predict"],
    "viewer": ["read"],
    "service": ["read", "write", "predict"],
}

# ── Static users for demo purposes ───────────────────────────────────────────
# In production these would be resolved from the database.
DEMO_USERS: Dict[str, Dict[str, Any]] = {
    "aureum_admin": {"password": "sovereign2024", "role": "admin"},
    "analyst_01": {"password": "analyst_pass", "role": "analyst"},
    "viewer_01": {"password": "viewer_pass", "role": "viewer"},
}


# ── Token operations ──────────────────────────────────────────────────────────

def create_access_token(subject: str, role: str) -> str:
    """Create a signed JWT access token."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub": subject,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=settings.JWT_EXPIRY_MINUTES),
    }
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)
    logger.debug("Token issued", subject=subject, role=role)
    return token


def verify_token(token: str) -> TokenPayload:
    """Verify and decode a JWT. Raises HTTPException on failure."""
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        return TokenPayload(**payload)
    except JWTError as exc:
        logger.warning("Token verification failed", error=str(exc))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token.",
            headers={"WWW-Authenticate": "Bearer"},
        )


# ── FastAPI dependencies ──────────────────────────────────────────────────────

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Security(bearer_scheme),
) -> UserContext:
    """FastAPI dependency — resolves current authenticated user."""
    token_data = verify_token(credentials.credentials)
    permissions = ROLE_PERMISSIONS.get(token_data.role, [])
    return UserContext(
        user_id=token_data.sub,
        role=token_data.role,
        permissions=permissions,
    )


def require_permission(permission: str):
    """Factory: FastAPI dependency that enforces a specific permission."""
    async def dependency(user: UserContext = Depends(get_current_user)) -> UserContext:
        if permission not in user.permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission '{permission}' required.",
            )
        return user
    return dependency


require_read = Depends(require_permission("read"))
require_write = Depends(require_permission("write"))
require_predict = Depends(require_permission("predict"))
require_admin = Depends(require_permission("admin"))
