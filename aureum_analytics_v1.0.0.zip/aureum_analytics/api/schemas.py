"""
AUREUM ANALYTICS — API Schemas
Pydantic request/response models for all API endpoints.
Strict validation, explicit typing, no implicit coercion.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, field_validator


# ── Authentication ─────────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    role: str


# ── Ingestion ──────────────────────────────────────────────────────────────────

class IngestRecord(BaseModel):
    source: str
    timestamp: Optional[datetime] = None
    payload: Dict[str, Any]


class IngestRequest(BaseModel):
    records: List[IngestRecord]
    schema_version: str = "1.0"
    pipeline: Optional[str] = None


class IngestResponse(BaseModel):
    batch_id: str
    accepted: int
    rejected: int
    status: str
    duration_ms: float


# ── Data Retrieval ─────────────────────────────────────────────────────────────

class DataQueryParams(BaseModel):
    source: Optional[str] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    limit: int = Field(default=1000, ge=1, le=100_000)
    offset: int = Field(default=0, ge=0)
    columns: Optional[List[str]] = None


class DataRecord(BaseModel):
    id: Optional[str] = None
    timestamp: Optional[datetime] = None
    source: Optional[str] = None
    data: Dict[str, Any]


class DataResponse(BaseModel):
    records: List[DataRecord]
    total: int
    page: int
    limit: int


# ── Prediction ─────────────────────────────────────────────────────────────────

class PredictRequest(BaseModel):
    model_name: str
    features: Dict[str, Any]
    version: Optional[str] = None
    use_cache: bool = True


class BatchPredictRequest(BaseModel):
    model_name: str
    records: List[Dict[str, Any]]
    version: Optional[str] = None


class PredictResponse(BaseModel):
    request_id: str
    model_name: str
    prediction: Union[float, int, str, List[Any]]
    confidence: Optional[float] = None
    latency_ms: float
    from_cache: bool = False
    timestamp: datetime


class BatchPredictResponse(BaseModel):
    model_name: str
    results: List[PredictResponse]
    total: int
    total_latency_ms: float


# ── Analytics ──────────────────────────────────────────────────────────────────

class AnalyticsRequest(BaseModel):
    dataset: str
    group_by: Optional[List[str]] = None
    metrics: Optional[Dict[str, str]] = None
    from_date: Optional[datetime] = None
    to_date: Optional[datetime] = None
    limit: int = Field(default=500, ge=1, le=10_000)


class AnalyticsResponse(BaseModel):
    dataset: str
    rows: int
    columns: List[str]
    data: List[Dict[str, Any]]
    generated_at: datetime


# ── Anomalies ──────────────────────────────────────────────────────────────────

class AnomalyQueryParams(BaseModel):
    source: Optional[str] = None
    priority: Optional[str] = None
    resolved: Optional[bool] = None
    from_date: Optional[datetime] = None
    limit: int = Field(default=100, ge=1, le=5_000)


class AnomalyRecord(BaseModel):
    alert_id: str
    alert_type: str
    priority: str
    source: str
    title: str
    description: str
    value: Optional[float] = None
    confidence: Optional[float] = None
    triggered_at: datetime
    resolved: bool


class AnomalyResponse(BaseModel):
    alerts: List[AnomalyRecord]
    total: int
    active: int


# ── Health ─────────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str
    version: str
    timestamp: datetime
    components: Dict[str, str]
