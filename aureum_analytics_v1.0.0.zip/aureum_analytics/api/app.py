"""
AUREUM ANALYTICS — FastAPI Application
Wires all routers, middleware, CORS, rate limiting, and lifecycle events.
"""

from __future__ import annotations

import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from aureum_analytics.api.routes.routes import (
    auth_router,
    data_router,
    ingest_router,
    analytics_router,
    predict_router,
    anomaly_router,
    health_router,
)
from aureum_analytics.config import configure_logging, get_logger, settings

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown lifecycle."""
    configure_logging(level="DEBUG" if settings.DEBUG else "INFO")
    logger.info(
        "AUREUM ANALYTICS starting",
        version=settings.APP_VERSION,
        env=settings.APP_ENV,
    )
    yield
    logger.info("AUREUM ANALYTICS shutting down")


def create_app() -> FastAPI:
    """Construct and configure the AUREUM FastAPI application."""
    app = FastAPI(
        title="AUREUM ANALYTICS",
        description=(
            "Autonomous Unified Runtime for Enterprise Modelling & Analytics. "
            "A cloud-native, enterprise-grade AI analytics and intelligence platform."
        ),
        version=settings.APP_VERSION,
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )

    # ── CORS ──────────────────────────────────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Request Timing Middleware ──────────────────────────────────────────────
    @app.middleware("http")
    async def add_process_time_header(request: Request, call_next):
        t0 = time.perf_counter()
        response: Response = await call_next(request)
        duration = (time.perf_counter() - t0) * 1000
        response.headers["X-Process-Time-Ms"] = f"{duration:.2f}"
        response.headers["X-Aureum-Version"] = settings.APP_VERSION
        return response

    # ── Global Exception Handler ───────────────────────────────────────────────
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error(
            "Unhandled exception",
            path=str(request.url),
            method=request.method,
            error=str(exc),
        )
        return JSONResponse(
            status_code=500,
            content={
                "error": "Internal server error",
                "detail": str(exc) if settings.DEBUG else "Contact support.",
            },
        )

    # ── Routers ───────────────────────────────────────────────────────────────
    API_PREFIX = "/api/v1"
    app.include_router(health_router, prefix=API_PREFIX)
    app.include_router(auth_router, prefix=API_PREFIX)
    app.include_router(data_router, prefix=API_PREFIX)
    app.include_router(ingest_router, prefix=API_PREFIX)
    app.include_router(analytics_router, prefix=API_PREFIX)
    app.include_router(predict_router, prefix=API_PREFIX)
    app.include_router(anomaly_router, prefix=API_PREFIX)

    return app


app = create_app()
