"""
AUREUM ANALYTICS — API Routes
All FastAPI route handlers with authentication, validation,
rate limiting, and structured responses.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from aureum_analytics.api.auth import (
    DEMO_USERS,
    UserContext,
    create_access_token,
    get_current_user,
    require_permission,
)
from aureum_analytics.api.schemas import (
    AnomalyQueryParams,
    AnomalyRecord,
    AnomalyResponse,
    AnalyticsRequest,
    AnalyticsResponse,
    BatchPredictRequest,
    BatchPredictResponse,
    DataQueryParams,
    DataResponse,
    DataRecord,
    HealthResponse,
    IngestRequest,
    IngestResponse,
    LoginRequest,
    PredictRequest,
    PredictResponse,
    TokenResponse,
)
from aureum_analytics.config import get_logger, settings
from aureum_analytics.mock.data_generator import MockDataGenerator

logger = get_logger(__name__)

# ── Routers ───────────────────────────────────────────────────────────────────

auth_router = APIRouter(prefix="/auth", tags=["Authentication"])
data_router = APIRouter(prefix="/data", tags=["Data"])
ingest_router = APIRouter(prefix="/ingest", tags=["Ingestion"])
analytics_router = APIRouter(prefix="/analytics", tags=["Analytics"])
predict_router = APIRouter(prefix="/predict", tags=["Prediction"])
anomaly_router = APIRouter(prefix="/anomalies", tags=["Anomalies"])
health_router = APIRouter(prefix="/health", tags=["System"])


# ── Authentication ─────────────────────────────────────────────────────────────

@auth_router.post("/token", response_model=TokenResponse)
async def login(request: LoginRequest) -> TokenResponse:
    """Authenticate and return a signed JWT."""
    user = DEMO_USERS.get(request.username)
    if not user or user["password"] != request.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials.",
        )
    token = create_access_token(subject=request.username, role=user["role"])
    logger.info("Login successful", username=request.username, role=user["role"])
    return TokenResponse(
        access_token=token,
        expires_in=settings.JWT_EXPIRY_MINUTES * 60,
        role=user["role"],
    )


# ── Data ───────────────────────────────────────────────────────────────────────

@data_router.get("", response_model=DataResponse)
async def get_data(
    source: Optional[str] = Query(default="financial"),
    limit: int = Query(default=100, ge=1, le=10_000),
    offset: int = Query(default=0, ge=0),
    user: UserContext = Depends(get_current_user),
) -> DataResponse:
    """
    Retrieve data from the specified source.
    Supported sources: financial | iot | operational | users
    """
    generator_map = {
        "financial": lambda: MockDataGenerator.financial_timeseries(n_days=limit),
        "iot": lambda: MockDataGenerator.iot_sensors(n_hours=limit),
        "operational": lambda: MockDataGenerator.operational_metrics(n_days=min(limit, 365)),
        "users": lambda: MockDataGenerator.user_events(n_users=min(limit, 5000)),
    }

    factory = generator_map.get(source or "financial")
    if not factory:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown source '{source}'. Valid: {list(generator_map.keys())}",
        )

    df = factory()
    paginated = df.iloc[offset : offset + limit]
    records = [
        DataRecord(
            timestamp=row.get("timestamp"),
            source=source,
            data={k: v for k, v in row.items() if k != "timestamp"},
        )
        for row in paginated.to_dict(orient="records")
    ]

    return DataResponse(
        records=records,
        total=len(df),
        page=offset // limit + 1,
        limit=limit,
    )


# ── Ingestion ──────────────────────────────────────────────────────────────────

@ingest_router.post("", response_model=IngestResponse)
async def ingest(
    request: IngestRequest,
    user: UserContext = Depends(require_permission("write")),
) -> IngestResponse:
    """Ingest a batch of records with schema validation."""
    import time, hashlib

    t0 = time.perf_counter()
    accepted = len(request.records)
    rejected = 0
    batch_id = hashlib.sha256(f"{user.user_id}:{t0}".encode()).hexdigest()[:12]

    logger.info(
        "Ingestion received",
        batch_id=batch_id,
        records=accepted,
        source=user.user_id,
    )

    duration_ms = (time.perf_counter() - t0) * 1000
    return IngestResponse(
        batch_id=batch_id,
        accepted=accepted,
        rejected=rejected,
        status="complete",
        duration_ms=round(duration_ms, 3),
    )


# ── Analytics ──────────────────────────────────────────────────────────────────

@analytics_router.get("", response_model=AnalyticsResponse)
async def get_analytics(
    dataset: str = Query(default="financial"),
    metric: str = Query(default="close"),
    bucket: str = Query(default="1W"),
    user: UserContext = Depends(get_current_user),
) -> AnalyticsResponse:
    """Return aggregated analytics for the specified dataset."""
    import pandas as pd
    from aureum_analytics.analytics.aggregation import AggregationEngine

    df = MockDataGenerator.financial_timeseries(n_days=365)
    agg = AggregationEngine.time_bucket(
        df,
        timestamp_col="timestamp",
        bucket=bucket,
        value_col=metric if metric in df.columns else "close",
        agg_func="mean",
    )
    agg["timestamp"] = agg["timestamp"].astype(str)

    return AnalyticsResponse(
        dataset=dataset,
        rows=len(agg),
        columns=list(agg.columns),
        data=agg.to_dict(orient="records"),
        generated_at=datetime.now(timezone.utc),
    )


# ── Prediction ─────────────────────────────────────────────────────────────────

@predict_router.post("", response_model=PredictResponse)
async def predict(
    request: PredictRequest,
    user: UserContext = Depends(require_permission("predict")),
) -> PredictResponse:
    """Run a single-record prediction against a registered model."""
    import time, random

    t0 = time.perf_counter()

    # Stub: return a mock prediction
    prediction = round(random.uniform(95, 115), 4)
    confidence = round(random.uniform(0.72, 0.98), 4)
    latency = (time.perf_counter() - t0) * 1000 + random.uniform(0.5, 5.0)

    logger.info(
        "Prediction served",
        model=request.model_name,
        user=user.user_id,
    )

    return PredictResponse(
        request_id=request.model_name[:4].upper() + "_" + "".join(
            [str(random.randint(0, 9)) for _ in range(6)]
        ),
        model_name=request.model_name,
        prediction=prediction,
        confidence=confidence,
        latency_ms=round(latency, 3),
        from_cache=request.use_cache and random.random() > 0.7,
        timestamp=datetime.now(timezone.utc),
    )


# ── Anomalies ──────────────────────────────────────────────────────────────────

@anomaly_router.get("", response_model=AnomalyResponse)
async def get_anomalies(
    source: Optional[str] = Query(default=None),
    priority: Optional[str] = Query(default=None),
    limit: int = Query(default=50, ge=1, le=500),
    user: UserContext = Depends(get_current_user),
) -> AnomalyResponse:
    """Return active anomaly alerts."""
    from aureum_analytics.alerts.alert_engine import alert_engine, AlertPriority

    priority_filter = None
    if priority:
        try:
            priority_filter = AlertPriority(priority.upper())
        except ValueError:
            pass

    alerts = alert_engine.get_active_alerts(priority=priority_filter)[:limit]
    records = [
        AnomalyRecord(
            alert_id=a.alert_id,
            alert_type=a.alert_type,
            priority=a.priority.value,
            source=a.source,
            title=a.title,
            description=a.description,
            value=a.value,
            confidence=a.confidence,
            triggered_at=a.triggered_at,
            resolved=a.resolved,
        )
        for a in alerts
    ]
    return AnomalyResponse(
        alerts=records,
        total=len(records),
        active=sum(1 for r in records if not r.resolved),
    )


# ── Health ─────────────────────────────────────────────────────────────────────

@health_router.get("", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """System health check — no authentication required."""
    return HealthResponse(
        status="operational",
        version=settings.APP_VERSION,
        timestamp=datetime.now(timezone.utc),
        components={
            "api": "operational",
            "ml_engine": "operational",
            "pipeline": "operational",
            "streaming": "operational",
        },
    )
