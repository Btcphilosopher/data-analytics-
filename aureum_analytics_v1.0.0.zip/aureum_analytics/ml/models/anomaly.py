"""
AUREUM ANALYTICS — Anomaly Detection Models
Isolation Forest, Z-Score, and IQR-based anomaly detection
with configurable sensitivity and structured output.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from aureum_analytics.config import get_logger, settings
from .base_model import AureumBaseModel

logger = get_logger(__name__)


class AnomalyResult(dict):
    """Structured anomaly detection output."""
    pass


class IsolationForestModel(AureumBaseModel):
    """
    Isolation Forest anomaly detector.

    Assigns each record an anomaly score in [-1, 0] where
    values < threshold indicate anomalies. Also provides
    a normalised confidence score in [0, 1].
    """

    MODEL_TYPE = "isolation_forest"

    DEFAULT_PARAMS: Dict[str, Any] = {
        "n_estimators": 200,
        "contamination": 0.05,
        "max_features": 1.0,
        "bootstrap": False,
        "random_state": 42,
        "n_jobs": -1,
    }

    def __init__(
        self,
        name: str = "isolation_forest",
        version: str = "1.0.0",
        hyperparameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        params = {**self.DEFAULT_PARAMS, **(hyperparameters or {})}
        super().__init__(name, version, params)
        self._scaler = StandardScaler()

    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "IsolationForestModel":
        X_scaled = self._scaler.fit_transform(X.fillna(0))
        self._model = IsolationForest(**self.hyperparameters)
        self._model.fit(X_scaled)
        self._metadata = self._build_metadata(
            feature_names=list(X.columns),
        )
        self._is_fitted = True
        logger.info(
            "Isolation Forest fitted",
            name=self.name,
            n_samples=len(X),
            features=len(X.columns),
        )
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Returns -1 (anomaly) or 1 (normal)."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        X_scaled = self._scaler.transform(X.fillna(0))
        return self._model.predict(X_scaled)

    def score_samples(self, X: pd.DataFrame) -> np.ndarray:
        """Return raw anomaly scores (lower = more anomalous)."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        X_scaled = self._scaler.transform(X.fillna(0))
        return self._model.score_samples(X_scaled)

    def detect(
        self,
        X: pd.DataFrame,
        threshold: Optional[float] = None,
    ) -> pd.DataFrame:
        """
        Run full anomaly detection pass.
        Returns input DataFrame augmented with:
          - anomaly_label (-1/1)
          - anomaly_score (raw)
          - anomaly_confidence (normalised 0-1)
          - is_anomaly (bool)
        """
        labels = self.predict(X)
        scores = self.score_samples(X)

        # Normalise scores to [0, 1] confidence
        s_min, s_max = scores.min(), scores.max()
        if s_max > s_min:
            confidence = (scores - s_min) / (s_max - s_min)
        else:
            confidence = np.zeros_like(scores)

        # Anomaly confidence is inverted (high conf = certain anomaly)
        anomaly_confidence = 1.0 - confidence

        result = X.copy()
        result["anomaly_label"] = labels
        result["anomaly_score"] = scores
        result["anomaly_confidence"] = anomaly_confidence
        result["is_anomaly"] = labels == -1

        n_anomalies = int((labels == -1).sum())
        logger.info(
            "Anomaly detection complete",
            name=self.name,
            total=len(X),
            anomalies=n_anomalies,
            rate=f"{n_anomalies/len(X):.2%}",
        )
        return result


class ZScoreAnomalyDetector:
    """
    Lightweight statistical anomaly detector using per-column z-scores.
    No training required — uses rolling or global statistics.
    """

    def __init__(
        self,
        threshold: float = 3.0,
        window: Optional[int] = None,
    ) -> None:
        self.threshold = threshold
        self.window = window

    def detect(
        self,
        df: pd.DataFrame,
        columns: List[str],
    ) -> pd.DataFrame:
        """
        Flag rows where any specified column exceeds z-score threshold.
        Returns df with 'is_anomaly' and per-column z-score columns.
        """
        result = df.copy()
        anomaly_mask = pd.Series([False] * len(df), index=df.index)

        for col in columns:
            if col not in df.columns:
                continue
            if self.window:
                roll = df[col].rolling(self.window, min_periods=2)
                mean = roll.mean()
                std = roll.std().replace(0, np.finfo(float).eps)
            else:
                mean = df[col].mean()
                std = df[col].std() or np.finfo(float).eps

            z = (df[col] - mean).abs() / std
            result[f"{col}_zscore"] = z
            anomaly_mask |= z > self.threshold

        result["is_anomaly"] = anomaly_mask
        result["anomaly_score"] = result[
            [f"{c}_zscore" for c in columns if f"{c}_zscore" in result]
        ].max(axis=1)

        logger.info(
            "Z-score anomaly detection complete",
            threshold=self.threshold,
            anomalies=int(anomaly_mask.sum()),
        )
        return result


class IQRAnomalyDetector:
    """IQR fence-based anomaly detector for simple univariate use cases."""

    def __init__(self, factor: float = 1.5) -> None:
        self.factor = factor

    def detect(
        self,
        df: pd.DataFrame,
        columns: List[str],
    ) -> pd.DataFrame:
        result = df.copy()
        anomaly_mask = pd.Series([False] * len(df), index=df.index)

        for col in columns:
            if col not in df.columns:
                continue
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            lower = q1 - self.factor * iqr
            upper = q3 + self.factor * iqr
            outside = ~df[col].between(lower, upper)
            result[f"{col}_iqr_flag"] = outside.astype(int)
            anomaly_mask |= outside

        result["is_anomaly"] = anomaly_mask
        logger.info(
            "IQR anomaly detection complete",
            anomalies=int(anomaly_mask.sum()),
        )
        return result
