"""
AUREUM ANALYTICS — Forecasting Models
Time-series forecasting via XGBoost with recursive multi-step
prediction, trend decomposition, and confidence intervals.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor

from aureum_analytics.config import get_logger, settings
from .base_model import AureumBaseModel

logger = get_logger(__name__)


class ForecastResult:
    """Structured container for a multi-step forecast output."""

    def __init__(
        self,
        forecast: np.ndarray,
        timestamps: pd.DatetimeIndex,
        lower_bound: Optional[np.ndarray] = None,
        upper_bound: Optional[np.ndarray] = None,
        confidence_level: float = 0.95,
    ) -> None:
        self.forecast = forecast
        self.timestamps = timestamps
        self.lower_bound = lower_bound
        self.upper_bound = upper_bound
        self.confidence_level = confidence_level

    def to_dataframe(self) -> pd.DataFrame:
        df = pd.DataFrame({
            "timestamp": self.timestamps,
            "forecast": self.forecast,
        })
        if self.lower_bound is not None:
            df["lower_bound"] = self.lower_bound
        if self.upper_bound is not None:
            df["upper_bound"] = self.upper_bound
        return df


class XGBoostForecaster(AureumBaseModel):
    """
    Multi-step ahead time-series forecaster using XGBoost.

    Architecture:
    - Constructs supervised learning problem from lag features
    - Recursive strategy for multi-step forecasting
    - Bootstrap-based confidence intervals
    - Residual std used for interval estimation if bootstrap disabled
    """

    MODEL_TYPE = "xgboost_forecaster"

    DEFAULT_PARAMS: Dict[str, Any] = {
        "n_estimators": 300,
        "learning_rate": 0.03,
        "max_depth": 5,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "reg_lambda": 1.0,
        "random_state": 42,
        "n_jobs": -1,
    }

    def __init__(
        self,
        name: str = "xgb_forecaster",
        version: str = "1.0.0",
        n_lags: int = 14,
        horizon: int = settings.FORECAST_HORIZON,
        hyperparameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        params = {**self.DEFAULT_PARAMS, **(hyperparameters or {})}
        super().__init__(name, version, params)
        self.n_lags = n_lags
        self.horizon = horizon
        self._scaler = StandardScaler()
        self._training_tail: Optional[np.ndarray] = None
        self._residual_std: float = 0.0

    def _build_supervised(
        self,
        series: np.ndarray,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Convert a 1-D series to lagged feature matrix."""
        X, y = [], []
        for i in range(self.n_lags, len(series)):
            X.append(series[i - self.n_lags : i])
            y.append(series[i])
        return np.array(X), np.array(y)

    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "XGBoostForecaster":
        """
        Fit the forecaster on a univariate target series.
        `X` is unused — target `y` must be a datetime-indexed Series.
        """
        if y is None:
            raise ValueError("Target series `y` required for forecasting.")

        scaled = self._scaler.fit_transform(y.values.reshape(-1, 1)).ravel()
        X_sup, y_sup = self._build_supervised(scaled)

        feature_names = [f"lag_{i+1}" for i in range(self.n_lags)]
        X_df = pd.DataFrame(X_sup, columns=feature_names)

        self._model = XGBRegressor(**self.hyperparameters)
        self._model.fit(X_df, y_sup)

        y_pred_scaled = self._model.predict(X_df)
        residuals = y_sup - y_pred_scaled
        self._residual_std = float(np.std(residuals))
        self._training_tail = scaled[-self.n_lags :]

        self._metadata = self._build_metadata(
            feature_names=feature_names,
            target_name=y.name,
            metrics={
                "rmse": float(np.sqrt(np.mean(residuals**2))),
                "residual_std": self._residual_std,
            },
        )
        self._is_fitted = True
        logger.info(
            "XGBoost forecaster fitted",
            name=self.name,
            n_lags=self.n_lags,
            horizon=self.horizon,
            rmse=f"{self._metadata.metrics['rmse']:.4f}",
        )
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Not used directly — use forecast() for multi-step output."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return self._model.predict(X)

    def forecast(
        self,
        steps: Optional[int] = None,
        last_known: Optional[np.ndarray] = None,
        freq: str = "D",
        start_date: Optional[pd.Timestamp] = None,
        confidence_level: float = 0.95,
    ) -> ForecastResult:
        """
        Generate multi-step recursive forecast.

        Args:
            steps: forecast horizon (defaults to self.horizon)
            last_known: raw (unscaled) last n_lag observations
            freq: pandas date offset for output timestamps
            start_date: start of forecast window
            confidence_level: interval coverage probability
        """
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")

        steps = steps or self.horizon
        history = self._training_tail.copy()
        if last_known is not None:
            scaled_tail = self._scaler.transform(
                last_known.reshape(-1, 1)
            ).ravel()
            history = scaled_tail[-self.n_lags :]

        feature_names = [f"lag_{i+1}" for i in range(self.n_lags)]
        predictions_scaled: List[float] = []

        for _ in range(steps):
            x = pd.DataFrame([history[-self.n_lags :]], columns=feature_names)
            pred_scaled = float(self._model.predict(x)[0])
            predictions_scaled.append(pred_scaled)
            history = np.append(history, pred_scaled)

        # Inverse scale
        forecast_array = self._scaler.inverse_transform(
            np.array(predictions_scaled).reshape(-1, 1)
        ).ravel()

        # Confidence intervals via residual std
        z = self._z_value(confidence_level)
        std_scaled = self._residual_std
        std_raw = float(
            self._scaler.scale_[0] * std_scaled if hasattr(self._scaler, "scale_") else std_scaled
        )
        lower = forecast_array - z * std_raw * np.sqrt(np.arange(1, steps + 1))
        upper = forecast_array + z * std_raw * np.sqrt(np.arange(1, steps + 1))

        # Build output timestamps
        if start_date is None:
            start_date = pd.Timestamp.now()
        timestamps = pd.date_range(start=start_date, periods=steps, freq=freq)

        logger.info(
            "Forecast generated",
            name=self.name,
            steps=steps,
            start=str(timestamps[0].date()),
            end=str(timestamps[-1].date()),
        )
        return ForecastResult(
            forecast=forecast_array,
            timestamps=timestamps,
            lower_bound=lower,
            upper_bound=upper,
            confidence_level=confidence_level,
        )

    @staticmethod
    def _z_value(confidence_level: float) -> float:
        """Return z-score for a given confidence level."""
        from scipy.stats import norm
        alpha = 1.0 - confidence_level
        return float(norm.ppf(1 - alpha / 2))
