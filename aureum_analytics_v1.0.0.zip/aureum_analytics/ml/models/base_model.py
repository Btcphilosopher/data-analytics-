"""
AUREUM ANALYTICS — Base Model Interface
Abstract base class for all AUREUM ML models.
Enforces: training, inference, serialisation, and versioning contracts.
"""

from __future__ import annotations

import hashlib
import json
import pickle
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pydantic import BaseModel

from aureum_analytics.config import get_logger, settings

logger = get_logger(__name__)


class ModelMetadata(BaseModel):
    """Immutable record of a trained model version."""

    model_id: str
    model_name: str
    model_type: str
    version: str
    trained_at: datetime
    feature_names: List[str]
    target_name: Optional[str] = None
    hyperparameters: Dict[str, Any] = {}
    metrics: Dict[str, float] = {}
    registry_path: Optional[str] = None


class AureumBaseModel(ABC):
    """
    Abstract base for all AUREUM ML models.

    Contract:
    - fit(): trains the model, stores metadata
    - predict(): returns inference results
    - save() / load(): serialise to / from disk
    - metadata: always reflects the current state
    """

    MODEL_TYPE: str = "base"

    def __init__(
        self,
        name: str,
        version: str = "1.0.0",
        hyperparameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.name = name
        self.version = version
        self.hyperparameters = hyperparameters or {}
        self._model: Any = None
        self._metadata: Optional[ModelMetadata] = None
        self._is_fitted: bool = False

    @property
    def is_fitted(self) -> bool:
        return self._is_fitted

    @property
    def metadata(self) -> Optional[ModelMetadata]:
        return self._metadata

    def _generate_model_id(self) -> str:
        ts = datetime.now(timezone.utc).isoformat()
        raw = f"{self.name}:{self.version}:{ts}"
        return hashlib.sha256(raw.encode()).hexdigest()[:12]

    def _build_metadata(
        self,
        feature_names: List[str],
        target_name: Optional[str] = None,
        metrics: Optional[Dict[str, float]] = None,
    ) -> ModelMetadata:
        return ModelMetadata(
            model_id=self._generate_model_id(),
            model_name=self.name,
            model_type=self.MODEL_TYPE,
            version=self.version,
            trained_at=datetime.now(timezone.utc),
            feature_names=feature_names,
            target_name=target_name,
            hyperparameters=self.hyperparameters,
            metrics=metrics or {},
        )

    @abstractmethod
    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "AureumBaseModel":
        """Train the model. Must set self._is_fitted = True."""

    @abstractmethod
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Run inference on input features."""

    def predict_proba(self, X: pd.DataFrame) -> Optional[np.ndarray]:
        """Return probability estimates if supported."""
        return None

    def save(self, directory: Optional[str] = None) -> str:
        """Serialise model to disk. Returns the saved path."""
        if not self._is_fitted:
            raise RuntimeError("Model must be fitted before saving.")

        registry = Path(directory or settings.MODEL_REGISTRY_PATH)
        registry.mkdir(parents=True, exist_ok=True)

        model_dir = registry / f"{self.name}_v{self.version}"
        model_dir.mkdir(exist_ok=True)

        model_path = model_dir / "model.pkl"
        meta_path = model_dir / "metadata.json"

        with open(model_path, "wb") as f:
            pickle.dump(self._model, f)

        if self._metadata:
            with open(meta_path, "w") as f:
                json.dump(self._metadata.model_dump(mode="json"), f, indent=2, default=str)

        logger.info(
            "Model saved",
            name=self.name,
            version=self.version,
            path=str(model_path),
        )
        return str(model_path)

    @classmethod
    def load(cls, directory: str) -> "AureumBaseModel":
        """Load a model from a saved directory."""
        model_path = Path(directory) / "model.pkl"
        meta_path = Path(directory) / "metadata.json"

        with open(model_path, "rb") as f:
            raw_model = pickle.load(f)

        instance = cls.__new__(cls)
        instance._model = raw_model
        instance._is_fitted = True

        if meta_path.exists():
            with open(meta_path) as f:
                meta_dict = json.load(f)
            instance._metadata = ModelMetadata(**meta_dict)
            instance.name = instance._metadata.model_name
            instance.version = instance._metadata.version
            instance.hyperparameters = instance._metadata.hyperparameters

        logger.info("Model loaded", path=directory)
        return instance

    def __repr__(self) -> str:
        status = "fitted" if self._is_fitted else "unfitted"
        return f"<{self.__class__.__name__}(name={self.name!r}, version={self.version!r}, status={status})>"
