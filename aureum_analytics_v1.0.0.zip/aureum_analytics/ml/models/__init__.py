"""AUREUM ANALYTICS — ML Models Registry."""

from .base_model import AureumBaseModel, ModelMetadata
from .regression import XGBoostRegressionModel, RidgeRegressionModel
from .classification import XGBoostClassificationModel, RandomForestClassificationModel
from .anomaly import IsolationForestModel, ZScoreAnomalyDetector, IQRAnomalyDetector
from .forecasting import XGBoostForecaster, ForecastResult

__all__ = [
    "AureumBaseModel", "ModelMetadata",
    "XGBoostRegressionModel", "RidgeRegressionModel",
    "XGBoostClassificationModel", "RandomForestClassificationModel",
    "IsolationForestModel", "ZScoreAnomalyDetector", "IQRAnomalyDetector",
    "XGBoostForecaster", "ForecastResult",
]
