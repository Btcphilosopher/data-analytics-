"""
AUREUM ANALYTICS — Regression Models
XGBoost and linear regression with cross-validation,
feature importance, and standardised evaluation metrics.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import ElasticNet, Lasso, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score
from xgboost import XGBRegressor

from aureum_analytics.config import get_logger
from .base_model import AureumBaseModel

logger = get_logger(__name__)


def _regression_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> Dict[str, float]:
    """Compute standard regression evaluation metrics."""
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = float(np.sqrt(mse))
    r2 = r2_score(y_true, y_pred)
    mape = float(
        np.mean(np.abs((y_true - y_pred) / np.where(y_true == 0, 1e-8, y_true))) * 100
    )
    return {"mae": mae, "mse": mse, "rmse": rmse, "r2": r2, "mape": mape}


class XGBoostRegressionModel(AureumBaseModel):
    """
    XGBoost regression model with configurable hyperparameters,
    cross-validation, and feature importance extraction.
    """

    MODEL_TYPE = "xgboost_regression"

    DEFAULT_PARAMS: Dict[str, Any] = {
        "n_estimators": 200,
        "learning_rate": 0.05,
        "max_depth": 6,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "reg_alpha": 0.1,
        "reg_lambda": 1.0,
        "random_state": 42,
        "n_jobs": -1,
    }

    def __init__(
        self,
        name: str = "xgb_regressor",
        version: str = "1.0.0",
        hyperparameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        params = {**self.DEFAULT_PARAMS, **(hyperparameters or {})}
        super().__init__(name, version, params)

    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "XGBoostRegressionModel":
        if y is None:
            raise ValueError("Target series `y` is required for regression training.")

        self._model = XGBRegressor(**self.hyperparameters)
        self._model.fit(
            X,
            y,
            eval_set=[(X, y)],
            verbose=False,
        )

        y_pred = self._model.predict(X)
        metrics = _regression_metrics(y.values, y_pred)
        self._metadata = self._build_metadata(
            feature_names=list(X.columns),
            target_name=y.name,
            metrics=metrics,
        )
        self._is_fitted = True
        logger.info(
            "XGBoost regression fitted",
            name=self.name,
            r2=f"{metrics['r2']:.4f}",
            rmse=f"{metrics['rmse']:.4f}",
        )
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return self._model.predict(X)

    def feature_importance(self) -> pd.Series:
        """Return feature importances as a sorted Series."""
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        imp = pd.Series(
            self._model.feature_importances_,
            index=self._metadata.feature_names,
        ).sort_values(ascending=False)
        return imp


class RidgeRegressionModel(AureumBaseModel):
    """L2-regularised linear regression (Ridge)."""

    MODEL_TYPE = "ridge_regression"

    def __init__(
        self,
        name: str = "ridge_regressor",
        version: str = "1.0.0",
        alpha: float = 1.0,
    ) -> None:
        super().__init__(name, version, {"alpha": alpha})

    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "RidgeRegressionModel":
        if y is None:
            raise ValueError("Target `y` required.")
        self._model = Ridge(**self.hyperparameters)
        self._model.fit(X, y)
        y_pred = self._model.predict(X)
        metrics = _regression_metrics(y.values, y_pred)
        self._metadata = self._build_metadata(
            feature_names=list(X.columns),
            target_name=y.name,
            metrics=metrics,
        )
        self._is_fitted = True
        logger.info("Ridge regression fitted", name=self.name, r2=f"{metrics['r2']:.4f}")
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return self._model.predict(X)

    @property
    def coefficients(self) -> pd.Series:
        return pd.Series(
            self._model.coef_,
            index=self._metadata.feature_names,
        )
