"""
AUREUM ANALYTICS — Classification Models
XGBoost and Random Forest classifiers with probability calibration,
threshold tuning, and structured evaluation.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from xgboost import XGBClassifier

from aureum_analytics.config import get_logger
from .base_model import AureumBaseModel

logger = get_logger(__name__)


def _classification_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: Optional[np.ndarray] = None,
) -> Dict[str, float]:
    """Compute classification evaluation metrics."""
    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "recall": recall_score(y_true, y_pred, average="weighted", zero_division=0),
        "f1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
    }
    if y_proba is not None and len(np.unique(y_true)) == 2:
        try:
            metrics["roc_auc"] = roc_auc_score(y_true, y_proba[:, 1])
        except Exception:
            pass
    return metrics


class XGBoostClassificationModel(AureumBaseModel):
    """
    XGBoost multi-class / binary classifier with probability output.
    """

    MODEL_TYPE = "xgboost_classification"

    DEFAULT_PARAMS: Dict[str, Any] = {
        "n_estimators": 200,
        "learning_rate": 0.05,
        "max_depth": 5,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "use_label_encoder": False,
        "eval_metric": "logloss",
        "random_state": 42,
        "n_jobs": -1,
    }

    def __init__(
        self,
        name: str = "xgb_classifier",
        version: str = "1.0.0",
        hyperparameters: Optional[Dict[str, Any]] = None,
        classification_threshold: float = 0.5,
    ) -> None:
        params = {**self.DEFAULT_PARAMS, **(hyperparameters or {})}
        super().__init__(name, version, params)
        self.threshold = classification_threshold
        self._classes: Optional[np.ndarray] = None

    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "XGBoostClassificationModel":
        if y is None:
            raise ValueError("Target series `y` required.")

        self._model = XGBClassifier(**{
            k: v for k, v in self.hyperparameters.items()
            if k != "use_label_encoder"
        })
        self._model.fit(X, y, eval_set=[(X, y)], verbose=False)
        self._classes = self._model.classes_

        y_pred = self._model.predict(X)
        y_proba = self._model.predict_proba(X)
        metrics = _classification_metrics(y.values, y_pred, y_proba)

        self._metadata = self._build_metadata(
            feature_names=list(X.columns),
            target_name=y.name,
            metrics=metrics,
        )
        self._is_fitted = True
        logger.info(
            "XGBoost classifier fitted",
            name=self.name,
            f1=f"{metrics['f1']:.4f}",
            accuracy=f"{metrics['accuracy']:.4f}",
        )
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return self._model.predict(X)

    def predict_proba(self, X: pd.DataFrame) -> Optional[np.ndarray]:
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return self._model.predict_proba(X)

    def predict_with_confidence(self, X: pd.DataFrame) -> pd.DataFrame:
        """Return predictions with confidence scores."""
        proba = self.predict_proba(X)
        pred = self.predict(X)
        result = pd.DataFrame({
            "prediction": pred,
            "confidence": proba.max(axis=1),
        })
        if self._classes is not None:
            for i, cls in enumerate(self._classes):
                result[f"prob_{cls}"] = proba[:, i]
        return result

    def feature_importance(self) -> pd.Series:
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return pd.Series(
            self._model.feature_importances_,
            index=self._metadata.feature_names,
        ).sort_values(ascending=False)


class RandomForestClassificationModel(AureumBaseModel):
    """Random Forest classifier with ensemble-based feature importance."""

    MODEL_TYPE = "random_forest_classification"

    DEFAULT_PARAMS: Dict[str, Any] = {
        "n_estimators": 100,
        "max_depth": None,
        "min_samples_split": 2,
        "random_state": 42,
        "n_jobs": -1,
    }

    def __init__(
        self,
        name: str = "rf_classifier",
        version: str = "1.0.0",
        hyperparameters: Optional[Dict[str, Any]] = None,
    ) -> None:
        params = {**self.DEFAULT_PARAMS, **(hyperparameters or {})}
        super().__init__(name, version, params)

    def fit(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
    ) -> "RandomForestClassificationModel":
        if y is None:
            raise ValueError("Target `y` required.")
        self._model = RandomForestClassifier(**self.hyperparameters)
        self._model.fit(X, y)
        y_pred = self._model.predict(X)
        y_proba = self._model.predict_proba(X)
        metrics = _classification_metrics(y.values, y_pred, y_proba)
        self._metadata = self._build_metadata(
            feature_names=list(X.columns),
            target_name=y.name,
            metrics=metrics,
        )
        self._is_fitted = True
        logger.info("Random Forest fitted", name=self.name, f1=f"{metrics['f1']:.4f}")
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        if not self._is_fitted:
            raise RuntimeError("Model not fitted.")
        return self._model.predict(X)

    def predict_proba(self, X: pd.DataFrame) -> Optional[np.ndarray]:
        return self._model.predict_proba(X) if self._is_fitted else None
