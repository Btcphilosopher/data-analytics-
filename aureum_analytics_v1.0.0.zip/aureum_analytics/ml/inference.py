"""
AUREUM ANALYTICS — Inference Engine
Production inference layer with model registry resolution,
async execution, result caching, and batch prediction.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from aureum_analytics.config import get_logger, settings
from aureum_analytics.ml.models.base_model import AureumBaseModel

logger = get_logger(__name__)


class InferenceRequest:
    """Structured inference request envelope."""

    def __init__(
        self,
        model_name: str,
        features: Dict[str, Any],
        request_id: Optional[str] = None,
        version: Optional[str] = None,
    ) -> None:
        self.model_name = model_name
        self.features = features
        self.request_id = request_id or self._gen_id()
        self.version = version
        self.created_at = datetime.now(timezone.utc)

    @staticmethod
    def _gen_id() -> str:
        import uuid
        return str(uuid.uuid4())[:8]


class InferenceResult:
    """Structured inference result."""

    def __init__(
        self,
        request_id: str,
        model_name: str,
        prediction: Any,
        confidence: Optional[float],
        latency_ms: float,
        from_cache: bool = False,
    ) -> None:
        self.request_id = request_id
        self.model_name = model_name
        self.prediction = prediction
        self.confidence = confidence
        self.latency_ms = latency_ms
        self.from_cache = from_cache
        self.created_at = datetime.now(timezone.utc)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "model_name": self.model_name,
            "prediction": self.prediction
            if isinstance(self.prediction, (int, float, str, list))
            else self.prediction.tolist() if hasattr(self.prediction, "tolist")
            else str(self.prediction),
            "confidence": self.confidence,
            "latency_ms": round(self.latency_ms, 3),
            "from_cache": self.from_cache,
            "timestamp": self.created_at.isoformat(),
        }


class InferenceEngine:
    """
    Production inference engine.

    Responsibilities:
    - Load and cache models from registry
    - Execute synchronous and async prediction
    - Maintain in-memory result cache
    - Log all inference events
    """

    def __init__(
        self,
        registry_path: Optional[str] = None,
        cache_ttl: int = settings.REDIS_CACHE_TTL,
    ) -> None:
        self._registry_path = Path(registry_path or settings.MODEL_REGISTRY_PATH)
        self._model_cache: Dict[str, AureumBaseModel] = {}
        self._result_cache: Dict[str, InferenceResult] = {}
        self._cache_ttl = cache_ttl

    def register_model(self, name: str, model: AureumBaseModel) -> None:
        """Register a pre-trained model instance directly."""
        self._model_cache[name] = model
        logger.info("Model registered in inference engine", name=name)

    def _resolve_model(self, model_name: str, version: Optional[str] = None) -> AureumBaseModel:
        """Resolve model from in-memory cache or disk registry."""
        cache_key = f"{model_name}_{version or 'latest'}"

        if cache_key in self._model_cache:
            return self._model_cache[cache_key]

        # Search registry on disk
        model_dirs = sorted(self._registry_path.glob(f"{model_name}_v*"))
        if not model_dirs:
            raise RuntimeError(f"No model found for '{model_name}' in registry.")

        target_dir = model_dirs[-1]  # latest
        if version:
            matching = [d for d in model_dirs if f"v{version}" in d.name]
            if matching:
                target_dir = matching[-1]

        from aureum_analytics.ml.models.base_model import AureumBaseModel as Base
        model = Base.load(str(target_dir))
        self._model_cache[cache_key] = model
        logger.info("Model loaded from registry", name=model_name, path=str(target_dir))
        return model

    def _cache_key(self, model_name: str, features: Dict[str, Any]) -> str:
        raw = json.dumps({"model": model_name, "features": features}, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def predict(
        self,
        model_name: str,
        features: Dict[str, Any],
        use_cache: bool = True,
        version: Optional[str] = None,
    ) -> InferenceResult:
        """Synchronous single-record prediction."""
        import time

        cache_key = self._cache_key(model_name, features)
        if use_cache and cache_key in self._result_cache:
            cached = self._result_cache[cache_key]
            cached.from_cache = True
            return cached

        model = self._resolve_model(model_name, version)
        X = pd.DataFrame([features])

        t0 = time.perf_counter()
        raw_pred = model.predict(X)
        proba = model.predict_proba(X)
        latency = (time.perf_counter() - t0) * 1000

        prediction = raw_pred[0] if hasattr(raw_pred, "__len__") else raw_pred
        confidence = None
        if proba is not None:
            confidence = float(proba.max(axis=1)[0])

        result = InferenceResult(
            request_id=self._cache_key(model_name, features)[:8],
            model_name=model_name,
            prediction=prediction,
            confidence=confidence,
            latency_ms=latency,
        )

        if use_cache:
            self._result_cache[cache_key] = result

        logger.debug(
            "Inference complete",
            model=model_name,
            prediction=str(prediction),
            latency_ms=f"{latency:.2f}",
        )
        return result

    def predict_batch(
        self,
        model_name: str,
        records: List[Dict[str, Any]],
        version: Optional[str] = None,
    ) -> List[InferenceResult]:
        """Batch inference across multiple records."""
        import time

        model = self._resolve_model(model_name, version)
        X = pd.DataFrame(records)

        t0 = time.perf_counter()
        raw_preds = model.predict(X)
        proba = model.predict_proba(X)
        latency = (time.perf_counter() - t0) * 1000

        results = []
        for i, pred in enumerate(raw_preds):
            conf = float(proba[i].max()) if proba is not None else None
            results.append(InferenceResult(
                request_id=f"batch_{i}",
                model_name=model_name,
                prediction=pred,
                confidence=conf,
                latency_ms=latency / len(records),
            ))

        logger.info(
            "Batch inference complete",
            model=model_name,
            records=len(records),
            total_latency_ms=f"{latency:.2f}",
        )
        return results

    async def predict_async(
        self,
        model_name: str,
        features: Dict[str, Any],
        version: Optional[str] = None,
    ) -> InferenceResult:
        """Async wrapper for non-blocking inference in async contexts."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.predict(model_name, features, version=version),
        )
