"""AUREUM ANALYTICS — Machine Learning Layer."""

from .models import (
    AureumBaseModel, ModelMetadata,
    XGBoostRegressionModel, RidgeRegressionModel,
    XGBoostClassificationModel, RandomForestClassificationModel,
    IsolationForestModel, ZScoreAnomalyDetector, IQRAnomalyDetector,
    XGBoostForecaster, ForecastResult,
)
from .training import ModelTrainer, TrainingRun
from .inference import InferenceEngine, InferenceRequest, InferenceResult

__all__ = [
    "AureumBaseModel", "ModelMetadata",
    "XGBoostRegressionModel", "RidgeRegressionModel",
    "XGBoostClassificationModel", "RandomForestClassificationModel",
    "IsolationForestModel", "ZScoreAnomalyDetector", "IQRAnomalyDetector",
    "XGBoostForecaster", "ForecastResult",
    "ModelTrainer", "TrainingRun",
    "InferenceEngine", "InferenceRequest", "InferenceResult",
]
