"""
AUREUM ANALYTICS — Training Orchestrator
Manages model training runs with cross-validation, early stopping,
metric tracking, and registry persistence.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Type

import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, StratifiedKFold

from aureum_analytics.config import get_logger, settings
from aureum_analytics.ml.models.base_model import AureumBaseModel

logger = get_logger(__name__)


class TrainingRun:
    """Record of a single model training execution."""

    def __init__(
        self,
        run_id: str,
        model_name: str,
        started_at: datetime,
    ) -> None:
        self.run_id = run_id
        self.model_name = model_name
        self.started_at = started_at
        self.completed_at: Optional[datetime] = None
        self.status: str = "running"
        self.cv_metrics: List[Dict[str, float]] = []
        self.final_metrics: Dict[str, float] = {}
        self.model_path: Optional[str] = None
        self.error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "model_name": self.model_name,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
            "cv_metrics": self.cv_metrics,
            "final_metrics": self.final_metrics,
            "model_path": self.model_path,
        }


class ModelTrainer:
    """
    Orchestrates model training with optional cross-validation,
    metric aggregation, and automatic registry persistence.
    """

    def __init__(
        self,
        registry_path: Optional[str] = None,
    ) -> None:
        self._registry_path = registry_path or settings.MODEL_REGISTRY_PATH
        self._runs: List[TrainingRun] = []

    def _generate_run_id(self, model_name: str) -> str:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        return f"{model_name}_{ts}"

    def train(
        self,
        model: AureumBaseModel,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None,
        save: bool = True,
    ) -> TrainingRun:
        """
        Execute a single training pass.
        Persists to registry if save=True.
        """
        run_id = self._generate_run_id(model.name)
        run = TrainingRun(
            run_id=run_id,
            model_name=model.name,
            started_at=datetime.now(timezone.utc),
        )

        logger.info("Training run started", run_id=run_id, model=model.name)

        try:
            model.fit(X, y)
            if model.metadata:
                run.final_metrics = model.metadata.metrics
            run.status = "complete"

            if save:
                run.model_path = model.save(self._registry_path)

            run.completed_at = datetime.now(timezone.utc)
            logger.info(
                "Training run complete",
                run_id=run_id,
                model=model.name,
                metrics=run.final_metrics,
            )
        except Exception as exc:
            run.status = "failed"
            run.error = str(exc)
            run.completed_at = datetime.now(timezone.utc)
            logger.error("Training run failed", run_id=run_id, error=str(exc))
            raise

        finally:
            self._runs.append(run)

        return run

    def cross_validate(
        self,
        model_class: Type[AureumBaseModel],
        model_kwargs: Dict[str, Any],
        X: pd.DataFrame,
        y: pd.Series,
        n_splits: int = 5,
        stratified: bool = False,
    ) -> Dict[str, Any]:
        """
        Perform k-fold cross-validation.
        Returns aggregated metrics across folds.
        """
        if stratified:
            kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
        else:
            kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

        fold_metrics: List[Dict[str, float]] = []

        for fold, (train_idx, val_idx) in enumerate(kf.split(X, y if stratified else None)):
            X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]

            model = model_class(**model_kwargs)
            model.fit(X_train, y_train)

            if model.metadata:
                fold_metrics.append(model.metadata.metrics)
                logger.debug(
                    "CV fold complete",
                    fold=fold + 1,
                    metrics=model.metadata.metrics,
                )

        # Aggregate
        if not fold_metrics:
            return {}

        all_keys = set().union(*fold_metrics)
        aggregated = {}
        for key in all_keys:
            values = [m[key] for m in fold_metrics if key in m]
            aggregated[f"{key}_mean"] = float(np.mean(values))
            aggregated[f"{key}_std"] = float(np.std(values))

        logger.info(
            "Cross-validation complete",
            n_splits=n_splits,
            metrics=aggregated,
        )
        return {"fold_metrics": fold_metrics, "aggregated": aggregated}

    def get_run_history(self) -> List[Dict[str, Any]]:
        return [r.to_dict() for r in self._runs]
