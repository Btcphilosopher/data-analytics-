"""
AUREUM ANALYTICS — pytest configuration
Shared fixtures and test settings.
"""

import pytest
import numpy as np
import pandas as pd


@pytest.fixture(autouse=True)
def set_random_seeds():
    """Ensure reproducible random state across all tests."""
    np.random.seed(42)
    yield
