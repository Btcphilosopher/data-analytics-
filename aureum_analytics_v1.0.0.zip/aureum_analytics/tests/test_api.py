"""
AUREUM ANALYTICS — Tests: API Layer
Integration tests for all FastAPI endpoints using TestClient.
Covers authentication, data retrieval, ingestion, prediction, and anomalies.
"""

from __future__ import annotations

from typing import Dict

import pytest
from fastapi.testclient import TestClient

from aureum_analytics.api.app import app


@pytest.fixture(scope="module")
def client() -> TestClient:
    return TestClient(app)


@pytest.fixture(scope="module")
def admin_token(client: TestClient) -> str:
    response = client.post(
        "/api/v1/auth/token",
        json={"username": "aureum_admin", "password": "sovereign2024"},
    )
    assert response.status_code == 200
    return response.json()["access_token"]


@pytest.fixture(scope="module")
def analyst_token(client: TestClient) -> str:
    response = client.post(
        "/api/v1/auth/token",
        json={"username": "analyst_01", "password": "analyst_pass"},
    )
    assert response.status_code == 200
    return response.json()["access_token"]


@pytest.fixture(scope="module")
def auth_headers(admin_token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {admin_token}"}


# ── Health ─────────────────────────────────────────────────────────────────────

class TestHealth:

    def test_health_check_no_auth(self, client: TestClient) -> None:
        r = client.get("/api/v1/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "operational"
        assert "version" in body
        assert "components" in body

    def test_health_includes_process_time_header(self, client: TestClient) -> None:
        r = client.get("/api/v1/health")
        assert "X-Process-Time-Ms" in r.headers


# ── Authentication ─────────────────────────────────────────────────────────────

class TestAuthentication:

    def test_login_admin_success(self, client: TestClient) -> None:
        r = client.post(
            "/api/v1/auth/token",
            json={"username": "aureum_admin", "password": "sovereign2024"},
        )
        assert r.status_code == 200
        body = r.json()
        assert "access_token" in body
        assert body["token_type"] == "bearer"
        assert body["role"] == "admin"

    def test_login_invalid_credentials(self, client: TestClient) -> None:
        r = client.post(
            "/api/v1/auth/token",
            json={"username": "aureum_admin", "password": "wrong_password"},
        )
        assert r.status_code == 401

    def test_login_unknown_user(self, client: TestClient) -> None:
        r = client.post(
            "/api/v1/auth/token",
            json={"username": "ghost_user", "password": "any"},
        )
        assert r.status_code == 401


# ── Data ───────────────────────────────────────────────────────────────────────

class TestDataEndpoints:

    def test_get_financial_data(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        r = client.get("/api/v1/data?source=financial&limit=10", headers=auth_headers)
        assert r.status_code == 200
        body = r.json()
        assert "records" in body
        assert len(body["records"]) <= 10
        assert body["limit"] == 10

    def test_get_iot_data(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        r = client.get("/api/v1/data?source=iot&limit=5", headers=auth_headers)
        assert r.status_code == 200
        assert len(r.json()["records"]) <= 5

    def test_get_data_unknown_source(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        r = client.get("/api/v1/data?source=unknown_xyz", headers=auth_headers)
        assert r.status_code == 400

    def test_get_data_unauthenticated(self, client: TestClient) -> None:
        r = client.get("/api/v1/data")
        assert r.status_code == 403


# ── Ingestion ──────────────────────────────────────────────────────────────────

class TestIngestionEndpoints:

    def test_ingest_records(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        payload = {
            "records": [
                {"source": "test", "payload": {"price": 100.0, "volume": 5000}},
                {"source": "test", "payload": {"price": 101.5, "volume": 4800}},
            ]
        }
        r = client.post("/api/v1/ingest", json=payload, headers=auth_headers)
        assert r.status_code == 200
        body = r.json()
        assert body["accepted"] == 2
        assert body["status"] == "complete"
        assert "batch_id" in body

    def test_ingest_requires_write_permission(
        self, client: TestClient, analyst_token: str
    ) -> None:
        # Analyst has 'predict' and 'read' only — no 'write'
        headers = {"Authorization": f"Bearer {analyst_token}"}
        payload = {"records": [{"source": "x", "payload": {"v": 1}}]}
        r = client.post("/api/v1/ingest", json=payload, headers=headers)
        assert r.status_code == 403


# ── Analytics ──────────────────────────────────────────────────────────────────

class TestAnalyticsEndpoints:

    def test_get_analytics(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        r = client.get(
            "/api/v1/analytics?dataset=financial&metric=close&bucket=1W",
            headers=auth_headers,
        )
        assert r.status_code == 200
        body = r.json()
        assert "data" in body
        assert body["rows"] > 0

    def test_analytics_requires_auth(self, client: TestClient) -> None:
        r = client.get("/api/v1/analytics")
        assert r.status_code == 403


# ── Prediction ─────────────────────────────────────────────────────────────────

class TestPredictionEndpoints:

    def test_predict_returns_result(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        payload = {
            "model_name": "xgb_forecaster",
            "features": {"price_lag_1": 105.0, "volume": 50000},
        }
        r = client.post("/api/v1/predict", json=payload, headers=auth_headers)
        assert r.status_code == 200
        body = r.json()
        assert "prediction" in body
        assert "confidence" in body
        assert "latency_ms" in body
        assert "request_id" in body

    def test_predict_requires_predict_permission(self, client: TestClient) -> None:
        # Viewer has read only
        login = client.post(
            "/api/v1/auth/token",
            json={"username": "viewer_01", "password": "viewer_pass"},
        )
        token = login.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"model_name": "test", "features": {"x": 1.0}}
        r = client.post("/api/v1/predict", json=payload, headers=headers)
        assert r.status_code == 403


# ── Anomalies ──────────────────────────────────────────────────────────────────

class TestAnomalyEndpoints:

    def test_get_anomalies(
        self, client: TestClient, auth_headers: Dict[str, str]
    ) -> None:
        r = client.get("/api/v1/anomalies?limit=10", headers=auth_headers)
        assert r.status_code == 200
        body = r.json()
        assert "alerts" in body
        assert "total" in body
        assert "active" in body
