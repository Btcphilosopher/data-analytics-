"""
AUREUM ANALYTICS — Tests: ML Models
Unit tests for regression, classification, anomaly detection,
and forecasting models.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from aureum_analytics.ml.models.regression import XGBoostRegressionModel, RidgeRegressionModel
from aureum_analytics.ml.models.classification import XGBoostClassificationModel
from aureum_analytics.ml.models.anomaly import (
    IsolationForestModel,
    ZScoreAnomalyDetector,
    IQRAnomalyDetector,
)
from aureum_analytics.ml.models.forecasting import XGBoostForecaster


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def regression_data() -> tuple[pd.DataFrame, pd.Series]:
    rng = np.random.default_rng(42)
    n = 200
    X = pd.DataFrame({
        "x1": rng.normal(0, 1, n),
        "x2": rng.normal(0, 1, n),
        "x3": rng.uniform(-1, 1, n),
    })
    y = pd.Series(3 * X["x1"] - 2 * X["x2"] + rng.normal(0, 0.5, n), name="target")
    return X, y


@pytest.fixture
def classification_data() -> tuple[pd.DataFrame, pd.Series]:
    rng = np.random.default_rng(42)
    n = 300
    X = pd.DataFrame({
        "f1": rng.normal(0, 1, n),
        "f2": rng.normal(0, 1, n),
    })
    y = pd.Series((X["f1"] + X["f2"] > 0).astype(int), name="label")
    return X, y


@pytest.fixture
def anomaly_data() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    n = 300
    df = pd.DataFrame({
        "a": rng.normal(0, 1, n),
        "b": rng.normal(5, 2, n),
    })
    # Inject clear anomalies
    df.loc[0:5, "a"] = 20.0
    df.loc[0:5, "b"] = 50.0
    return df


@pytest.fixture
def timeseries_target() -> pd.Series:
    rng = np.random.default_rng(42)
    n = 120
    t = np.arange(n)
    signal = 100 + 0.3 * t + 5 * np.sin(2 * np.pi * t / 30)
    noise = rng.normal(0, 2, n)
    return pd.Series(signal + noise, name="price")


# ── Regression ────────────────────────────────────────────────────────────────

class TestRegressionModels:

    def test_xgboost_regression_fit_predict(
        self, regression_data: tuple
    ) -> None:
        X, y = regression_data
        model = XGBoostRegressionModel(name="test_xgb")
        assert not model.is_fitted
        model.fit(X, y)
        assert model.is_fitted
        preds = model.predict(X)
        assert len(preds) == len(X)
        assert model.metadata is not None
        assert model.metadata.metrics["r2"] > 0.8

    def test_xgboost_regression_feature_importance(
        self, regression_data: tuple
    ) -> None:
        X, y = regression_data
        model = XGBoostRegressionModel()
        model.fit(X, y)
        imp = model.feature_importance()
        assert set(imp.index) == set(X.columns)
        assert imp.sum() > 0

    def test_ridge_regression_fit_predict(
        self, regression_data: tuple
    ) -> None:
        X, y = regression_data
        model = RidgeRegressionModel(alpha=1.0)
        model.fit(X, y)
        preds = model.predict(X)
        assert len(preds) == len(X)
        assert len(model.coefficients) == len(X.columns)

    def test_unfitted_model_raises(self) -> None:
        model = XGBoostRegressionModel()
        with pytest.raises(RuntimeError, match="not fitted"):
            model.predict(pd.DataFrame({"x": [1.0]}))

    def test_missing_target_raises(self, regression_data: tuple) -> None:
        X, _ = regression_data
        model = XGBoostRegressionModel()
        with pytest.raises(ValueError):
            model.fit(X, y=None)


# ── Classification ────────────────────────────────────────────────────────────

class TestClassificationModels:

    def test_xgboost_classification_fit_predict(
        self, classification_data: tuple
    ) -> None:
        X, y = classification_data
        model = XGBoostClassificationModel()
        model.fit(X, y)
        preds = model.predict(X)
        assert len(preds) == len(X)
        assert set(preds).issubset({0, 1})
        assert model.metadata.metrics["accuracy"] > 0.75

    def test_predict_proba_shape(self, classification_data: tuple) -> None:
        X, y = classification_data
        model = XGBoostClassificationModel()
        model.fit(X, y)
        proba = model.predict_proba(X)
        assert proba is not None
        assert proba.shape == (len(X), 2)
        assert np.allclose(proba.sum(axis=1), 1.0, atol=1e-5)

    def test_predict_with_confidence(self, classification_data: tuple) -> None:
        X, y = classification_data
        model = XGBoostClassificationModel()
        model.fit(X, y)
        result = model.predict_with_confidence(X)
        assert "prediction" in result.columns
        assert "confidence" in result.columns
        assert result["confidence"].between(0, 1).all()


# ── Anomaly Detection ─────────────────────────────────────────────────────────

class TestAnomalyModels:

    def test_isolation_forest_detect(self, anomaly_data: pd.DataFrame) -> None:
        model = IsolationForestModel(
            hyperparameters={"n_estimators": 50, "contamination": 0.05, "random_state": 42}
        )
        model.fit(anomaly_data)
        result = model.detect(anomaly_data)
        assert "is_anomaly" in result.columns
        assert "anomaly_confidence" in result.columns
        # Injected anomalies should be flagged
        assert result["is_anomaly"].sum() > 0

    def test_zscore_detector(self, anomaly_data: pd.DataFrame) -> None:
        detector = ZScoreAnomalyDetector(threshold=3.0)
        result = detector.detect(anomaly_data, columns=["a", "b"])
        assert "is_anomaly" in result.columns
        assert result["is_anomaly"].sum() > 0

    def test_iqr_detector(self, anomaly_data: pd.DataFrame) -> None:
        detector = IQRAnomalyDetector(factor=1.5)
        result = detector.detect(anomaly_data, columns=["a", "b"])
        assert "is_anomaly" in result.columns
        # Clear anomalies (value=20, 50) should exceed IQR bounds
        assert result["is_anomaly"].sum() > 0


# ── Forecasting ───────────────────────────────────────────────────────────────

class TestForecasting:

    def test_forecaster_fit_and_forecast(self, timeseries_target: pd.Series) -> None:
        model = XGBoostForecaster(n_lags=7, horizon=14)
        model.fit(pd.DataFrame(), y=timeseries_target)
        assert model.is_fitted

        result = model.forecast(steps=14, freq="D")
        assert len(result.forecast) == 14
        assert len(result.timestamps) == 14
        assert result.lower_bound is not None
        assert result.upper_bound is not None
        # CI should straddle forecast
        assert (result.upper_bound >= result.forecast).all()
        assert (result.forecast >= result.lower_bound).all()

    def test_forecast_to_dataframe(self, timeseries_target: pd.Series) -> None:
        model = XGBoostForecaster(n_lags=7)
        model.fit(pd.DataFrame(), y=timeseries_target)
        result = model.forecast(steps=7)
        df = result.to_dataframe()
        assert "timestamp" in df.columns
        assert "forecast" in df.columns
        assert len(df) == 7

    def test_unfitted_forecaster_raises(self) -> None:
        model = XGBoostForecaster()
        with pytest.raises(RuntimeError):
            model.forecast(steps=5)
