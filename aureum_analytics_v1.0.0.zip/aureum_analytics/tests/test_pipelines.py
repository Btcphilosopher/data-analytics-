"""
AUREUM ANALYTICS — Tests: Pipeline Engine
Integration tests for pipeline composition, execution,
config loading, and error handling strategies.
"""

from __future__ import annotations

import asyncio

import numpy as np
import pandas as pd
import pytest

from aureum_analytics.pipelines.pipeline_engine import Pipeline, PipelineReport
from aureum_analytics.pipelines.config_loader import ConfigLoader
from aureum_analytics.preprocessing.cleaning import DataCleaner
from aureum_analytics.preprocessing.feature_engineering import FeatureEngineer


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def base_df() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    n = 100
    return pd.DataFrame({
        "timestamp": pd.date_range("2024-01-01", periods=n, freq="D"),
        "price": rng.uniform(90, 120, n),
        "volume": rng.integers(10_000, 100_000, n).astype(float),
        "label": ["A", "B"] * 50,
    })


# ── Pipeline Engine ───────────────────────────────────────────────────────────

class TestPipelineEngine:

    def test_empty_pipeline(self, base_df: pd.DataFrame) -> None:
        """Empty pipeline passes data through unchanged."""
        pipeline = Pipeline("empty")
        result_df, report = asyncio.get_event_loop().run_until_complete(
            pipeline.run(base_df)
        )
        assert len(result_df) == len(base_df)
        assert report.status == "complete"
        assert len(report.steps) == 0

    def test_single_step_pipeline(self, base_df: pd.DataFrame) -> None:
        def add_flag(df: pd.DataFrame) -> pd.DataFrame:
            df = df.copy()
            df["processed"] = True
            return df

        pipeline = Pipeline("single_step")
        pipeline.add_step("add_flag", add_flag)
        result_df, report = asyncio.get_event_loop().run_until_complete(
            pipeline.run(base_df)
        )
        assert "processed" in result_df.columns
        assert report.status == "complete"
        assert report.steps[0].status == "success"

    def test_multi_step_pipeline(self, base_df: pd.DataFrame) -> None:
        def step_a(df: pd.DataFrame) -> pd.DataFrame:
            df = df.copy()
            df["step_a"] = 1
            return df

        def step_b(df: pd.DataFrame) -> pd.DataFrame:
            df = df.copy()
            df["step_b"] = 2
            return df

        pipeline = Pipeline("multi_step")
        pipeline.add_step("step_a", step_a)
        pipeline.add_step("step_b", step_b)

        result_df, report = asyncio.get_event_loop().run_until_complete(
            pipeline.run(base_df)
        )
        assert "step_a" in result_df.columns
        assert "step_b" in result_df.columns
        assert len(report.steps) == 2
        assert all(s.status == "success" for s in report.steps)

    def test_step_chaining_returns_self(self, base_df: pd.DataFrame) -> None:
        """add_step should return Pipeline for method chaining."""
        pipeline = Pipeline("chained")
        result = pipeline.add_step("noop", lambda df: df)
        assert result is pipeline

    def test_disabled_step_skipped(self, base_df: pd.DataFrame) -> None:
        def should_not_run(df: pd.DataFrame) -> pd.DataFrame:
            raise RuntimeError("This step should have been skipped")

        pipeline = Pipeline("disabled_test")
        pipeline.add_step("disabled", should_not_run, enabled=False)
        result_df, report = asyncio.get_event_loop().run_until_complete(
            pipeline.run(base_df)
        )
        assert report.steps[0].status == "skipped"
        assert len(result_df) == len(base_df)

    def test_on_error_raise(self, base_df: pd.DataFrame) -> None:
        def failing_step(df: pd.DataFrame) -> pd.DataFrame:
            raise ValueError("Deliberate failure")

        pipeline = Pipeline("error_raise")
        pipeline.add_step("fail", failing_step, on_error="raise")
        with pytest.raises(ValueError, match="Deliberate failure"):
            asyncio.get_event_loop().run_until_complete(pipeline.run(base_df))

    def test_on_error_skip(self, base_df: pd.DataFrame) -> None:
        def failing_step(df: pd.DataFrame) -> pd.DataFrame:
            raise ValueError("Deliberate failure")

        def good_step(df: pd.DataFrame) -> pd.DataFrame:
            df = df.copy()
            df["after_skip"] = True
            return df

        pipeline = Pipeline("error_skip")
        pipeline.add_step("fail", failing_step, on_error="skip")
        pipeline.add_step("good", good_step)

        result_df, report = asyncio.get_event_loop().run_until_complete(
            pipeline.run(base_df)
        )
        assert "after_skip" in result_df.columns
        assert report.steps[0].status == "failed"
        assert report.steps[1].status == "success"

    def test_async_step(self, base_df: pd.DataFrame) -> None:
        async def async_step(df: pd.DataFrame) -> pd.DataFrame:
            await asyncio.sleep(0)
            df = df.copy()
            df["async_processed"] = True
            return df

        pipeline = Pipeline("async_test")
        pipeline.add_step("async_step", async_step)
        result_df, report = asyncio.get_event_loop().run_until_complete(
            pipeline.run(base_df)
        )
        assert "async_processed" in result_df.columns
        assert report.steps[0].status == "success"

    def test_pipeline_report_timing(self, base_df: pd.DataFrame) -> None:
        pipeline = Pipeline("timing_test")
        pipeline.add_step("noop", lambda df: df)
        _, report = asyncio.get_event_loop().run_until_complete(pipeline.run(base_df))
        assert report.total_duration_ms >= 0
        assert report.steps[0].duration_ms >= 0

    def test_remove_step(self, base_df: pd.DataFrame) -> None:
        pipeline = Pipeline("remove_test")
        pipeline.add_step("step_a", lambda df: df)
        pipeline.add_step("step_b", lambda df: df)
        assert len(pipeline) == 2
        pipeline.remove_step("step_a")
        assert len(pipeline) == 1

    def test_run_sync_wrapper(self, base_df: pd.DataFrame) -> None:
        pipeline = Pipeline("sync_test")
        pipeline.add_step("noop", lambda df: df)
        result_df, report = pipeline.run_sync(base_df)
        assert report.status == "complete"
        assert len(result_df) == len(base_df)


# ── Config Loader ─────────────────────────────────────────────────────────────

class TestConfigLoader:

    def test_load_financial_pipeline_from_yaml(self, base_df: pd.DataFrame) -> None:
        pipeline = ConfigLoader.from_file(
            "aureum_analytics/pipelines/configs/financial_pipeline.yaml"
        )
        assert pipeline.name == "financial_preprocessing"
        assert len(pipeline) > 0

    def test_load_iot_pipeline_from_yaml(self) -> None:
        pipeline = ConfigLoader.from_file(
            "aureum_analytics/pipelines/configs/iot_pipeline.yaml"
        )
        assert pipeline.name == "iot_sensor_pipeline"

    def test_from_dict(self, base_df: pd.DataFrame) -> None:
        config = {
            "name": "test_pipeline",
            "version": "1.0.0",
            "steps": [
                {
                    "name": "clean",
                    "type": "clean",
                    "params": {"null_strategy": "mean"},
                }
            ],
        }
        pipeline = ConfigLoader.from_dict(config)
        assert pipeline.name == "test_pipeline"
        assert len(pipeline) == 1

    def test_unknown_step_type_skipped(self) -> None:
        config = {
            "name": "unknown_steps",
            "steps": [
                {"name": "ghost", "type": "unknown_step_type_xyz", "params": {}},
            ],
        }
        pipeline = ConfigLoader.from_dict(config)
        # Unknown step should be skipped, pipeline still valid
        assert len(pipeline) == 0

    def test_missing_config_file_raises(self) -> None:
        with pytest.raises(FileNotFoundError):
            ConfigLoader.from_file("nonexistent_pipeline.yaml")
