"""
AUREUM ANALYTICS — Tests: Preprocessing Layer
Unit tests for cleaning, transformation, and feature engineering.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from aureum_analytics.preprocessing.cleaning import DataCleaner
from aureum_analytics.preprocessing.transformation import Transformer
from aureum_analytics.preprocessing.feature_engineering import FeatureEngineer


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_df() -> pd.DataFrame:
    """Clean numeric DataFrame for transformation tests."""
    return pd.DataFrame({
        "timestamp": pd.date_range("2024-01-01", periods=50, freq="D"),
        "price": np.linspace(100.0, 150.0, 50) + np.random.default_rng(0).normal(0, 2, 50),
        "volume": np.random.default_rng(1).integers(10_000, 100_000, 50).astype(float),
        "category": ["A", "B"] * 25,
    })


@pytest.fixture
def dirty_df() -> pd.DataFrame:
    """DataFrame with duplicates, nulls, and outliers."""
    df = pd.DataFrame({
        "value": [10.0, 10.0, None, 50.0, None, 12.0, 500.0, 11.0],
        "label": ["x", "x", "y", "y", "z", "z", "w", "w"],
    })
    return df


# ── DataCleaner ───────────────────────────────────────────────────────────────

class TestDataCleaner:

    def test_drop_duplicates(self, dirty_df: pd.DataFrame) -> None:
        cleaned, dropped = DataCleaner.drop_duplicates(dirty_df)
        assert dropped >= 0
        assert len(cleaned) <= len(dirty_df)

    def test_handle_nulls_drop(self, dirty_df: pd.DataFrame) -> None:
        cleaned, resolved = DataCleaner.handle_nulls(dirty_df, strategy="drop")
        assert cleaned["value"].isnull().sum() == 0
        assert resolved >= 0

    def test_handle_nulls_fill(self, dirty_df: pd.DataFrame) -> None:
        cleaned, _ = DataCleaner.handle_nulls(dirty_df, strategy="fill", fill_value=0.0)
        assert cleaned["value"].isnull().sum() == 0
        assert (cleaned["value"] == 0.0).any()

    def test_handle_nulls_mean(self, dirty_df: pd.DataFrame) -> None:
        cleaned, _ = DataCleaner.handle_nulls(dirty_df, strategy="mean")
        assert cleaned["value"].isnull().sum() == 0

    def test_remove_outliers_iqr(self, dirty_df: pd.DataFrame) -> None:
        df_no_nulls, _ = DataCleaner.handle_nulls(dirty_df, strategy="fill", fill_value=10.0)
        cleaned, removed = DataCleaner.remove_outliers(df_no_nulls, ["value"], method="iqr")
        assert removed >= 0
        assert 500.0 not in cleaned["value"].values

    def test_remove_outliers_zscore(self, dirty_df: pd.DataFrame) -> None:
        df_no_nulls, _ = DataCleaner.handle_nulls(dirty_df, strategy="fill", fill_value=10.0)
        cleaned, removed = DataCleaner.remove_outliers(
            df_no_nulls, ["value"], method="zscore", z_threshold=2.0
        )
        assert removed >= 0

    def test_full_clean_pipeline(self, dirty_df: pd.DataFrame) -> None:
        cleaned, report = DataCleaner.clean(
            dirty_df,
            drop_dups=True,
            null_strategy="mean",
            outlier_columns=["value"],
        )
        assert "rows_before" in report
        assert "rows_after" in report
        assert report["rows_after"] <= report["rows_before"]

    def test_enforce_dtypes(self, sample_df: pd.DataFrame) -> None:
        df_str = sample_df.copy()
        df_str["price"] = df_str["price"].astype(str)
        cleaned, failed = DataCleaner.enforce_dtypes(df_str, {"price": "float"})
        assert "price" not in failed or len(failed) == 0


# ── Transformer ───────────────────────────────────────────────────────────────

class TestTransformer:

    def test_standard_scaler(self, sample_df: pd.DataFrame) -> None:
        transformer = Transformer()
        cols = ["price", "volume"]
        scaled = transformer.fit_transform_scale(sample_df, cols, method="standard")
        assert abs(scaled["price"].mean()) < 0.1
        assert abs(scaled["price"].std() - 1.0) < 0.1

    def test_minmax_scaler(self, sample_df: pd.DataFrame) -> None:
        transformer = Transformer()
        cols = ["price", "volume"]
        scaled = transformer.fit_transform_scale(sample_df, cols, method="minmax")
        assert scaled["price"].min() >= 0.0
        assert scaled["price"].max() <= 1.0

    def test_label_encode(self, sample_df: pd.DataFrame) -> None:
        transformer = Transformer()
        encoded = transformer.label_encode(sample_df, ["category"])
        assert encoded["category"].dtype in [np.int32, np.int64, int]

    def test_resample_timeseries(self, sample_df: pd.DataFrame) -> None:
        resampled = Transformer.resample_timeseries(
            sample_df, "timestamp", frequency="1W", agg_func="mean"
        )
        assert "timestamp" in resampled.columns
        assert len(resampled) < len(sample_df)

    def test_log_transform(self, sample_df: pd.DataFrame) -> None:
        logged = Transformer.log_transform(sample_df, ["price", "volume"])
        assert (logged["price"] > 0).all()


# ── FeatureEngineer ───────────────────────────────────────────────────────────

class TestFeatureEngineer:

    def test_rolling_mean(self, sample_df: pd.DataFrame) -> None:
        result = FeatureEngineer.rolling_mean(sample_df, "price", windows=[7, 14])
        assert "price_roll_mean_7" in result.columns
        assert "price_roll_mean_14" in result.columns
        assert len(result) == len(sample_df)

    def test_lag_features(self, sample_df: pd.DataFrame) -> None:
        result = FeatureEngineer.lag_features(sample_df, "price", lags=[1, 3, 7])
        assert "price_lag_1" in result.columns
        assert "price_lag_7" in result.columns
        assert pd.isna(result["price_lag_7"].iloc[0])

    def test_temporal_features(self, sample_df: pd.DataFrame) -> None:
        result = FeatureEngineer.temporal_features(sample_df, "timestamp")
        for col in ["hour", "day_of_week", "month", "quarter", "year", "is_weekend"]:
            assert col in result.columns

    def test_bollinger_bands(self, sample_df: pd.DataFrame) -> None:
        result = FeatureEngineer.bollinger_bands(sample_df, "price", window=10)
        assert "price_bb_upper" in result.columns
        assert "price_bb_lower" in result.columns
        assert (result["price_bb_upper"] >= result["price_bb_lower"]).all()

    def test_rsi(self, sample_df: pd.DataFrame) -> None:
        result = FeatureEngineer.rsi(sample_df, "price", period=7)
        assert "price_rsi_7" in result.columns
        rsi_values = result["price_rsi_7"].dropna()
        assert (rsi_values >= 0).all()
        assert (rsi_values <= 100).all()

    def test_zscore_features(self, sample_df: pd.DataFrame) -> None:
        result = FeatureEngineer.zscore_features(sample_df, ["price"])
        assert "price_zscore" in result.columns
        z = result["price_zscore"].dropna()
        assert abs(z.mean()) < 0.5
