"""
AUREUM ANALYTICS — Mock Data Generator
Deterministic synthetic data for development, testing,
and pipeline validation. Covers financial, IoT, and operational domains.
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import numpy as np
import pandas as pd

from aureum_analytics.config import get_logger

logger = get_logger(__name__)

# ── Seeded RNG for reproducibility ────────────────────────────────────────────
RNG = np.random.default_rng(42)


class MockDataGenerator:
    """
    Factory for structured synthetic datasets.

    All generators:
    - are deterministically seeded
    - return typed DataFrames
    - include injected anomalies for ML validation
    """

    # ── Financial Data ─────────────────────────────────────────────────────────

    @staticmethod
    def financial_timeseries(
        n_days: int = 365,
        ticker: str = "AURUM",
        start_date: Optional[datetime] = None,
        inject_anomalies: int = 5,
    ) -> pd.DataFrame:
        """
        Generate OHLCV market data with realistic price dynamics
        (geometric Brownian motion) and injected anomalies.
        """
        start = start_date or datetime(2024, 1, 1, tzinfo=timezone.utc)
        dates = [start + timedelta(days=i) for i in range(n_days)]

        # GBM price series
        mu, sigma = 0.0003, 0.018
        log_returns = RNG.normal(mu, sigma, n_days)
        price = 100.0 * np.exp(np.cumsum(log_returns))

        volume_base = RNG.integers(800_000, 3_000_000, n_days)
        spreads = price * RNG.uniform(0.0005, 0.002, n_days)

        # OHLCV
        high = price * (1 + RNG.uniform(0.001, 0.015, n_days))
        low = price * (1 - RNG.uniform(0.001, 0.015, n_days))
        open_ = np.roll(price, 1)
        open_[0] = price[0]

        df = pd.DataFrame({
            "timestamp": dates,
            "ticker": ticker,
            "open": np.round(open_, 4),
            "high": np.round(high, 4),
            "low": np.round(low, 4),
            "close": np.round(price, 4),
            "volume": volume_base.astype(int),
            "spread": np.round(spreads, 6),
            "market_cap": np.round(price * 1_000_000, 2),
        })

        # Inject anomalies (price spikes)
        if inject_anomalies > 0:
            anomaly_idx = RNG.choice(n_days, inject_anomalies, replace=False)
            df.loc[anomaly_idx, "close"] *= RNG.uniform(1.05, 1.20, inject_anomalies)
            df.loc[anomaly_idx, "volume"] *= RNG.integers(3, 8, inject_anomalies)
            df.loc[anomaly_idx, "anomaly"] = True
            df["anomaly"] = df["anomaly"].fillna(False)

        logger.debug("Financial timeseries generated", rows=len(df), ticker=ticker)
        return df

    @staticmethod
    def multi_asset_portfolio(
        n_assets: int = 5,
        n_days: int = 252,
        correlation: float = 0.4,
    ) -> pd.DataFrame:
        """Generate correlated multi-asset return series."""
        tickers = [f"ASSET_{chr(65+i)}" for i in range(n_assets)]
        returns_list = []

        for i in range(n_assets):
            mu = RNG.uniform(0.0001, 0.0006)
            sigma = RNG.uniform(0.01, 0.025)
            r = RNG.normal(mu, sigma, n_days)
            returns_list.append(r)

        # Introduce correlation
        base_factor = RNG.normal(0, 0.01, n_days)
        for i in range(n_assets):
            returns_list[i] += correlation * base_factor

        start = datetime(2024, 1, 1)
        dates = [start + timedelta(days=i) for i in range(n_days)]

        data: dict = {"timestamp": dates}
        for ticker, ret in zip(tickers, returns_list):
            price = 100.0 * np.exp(np.cumsum(ret))
            data[ticker] = np.round(price, 4)

        return pd.DataFrame(data)

    # ── IoT Sensor Data ────────────────────────────────────────────────────────

    @staticmethod
    def iot_sensors(
        n_hours: int = 720,
        n_sensors: int = 4,
        inject_faults: int = 10,
    ) -> pd.DataFrame:
        """
        Generate multi-sensor IoT time-series with
        realistic noise profiles and injected fault events.
        """
        start = datetime(2024, 1, 1, tzinfo=timezone.utc)
        timestamps = [start + timedelta(hours=i) for i in range(n_hours)]

        sensor_params = {
            "temperature": {"base": 22.0, "noise": 1.5, "drift": 0.001},
            "pressure": {"base": 1013.25, "noise": 2.0, "drift": 0.0},
            "humidity": {"base": 55.0, "noise": 5.0, "drift": 0.002},
            "vibration": {"base": 0.05, "noise": 0.02, "drift": 0.0},
        }

        records: List[dict] = []
        for i, ts in enumerate(timestamps):
            row: dict = {"timestamp": ts, "sensor_id": f"SENSOR_{(i % n_sensors) + 1:02d}"}
            for sensor, params in sensor_params.items():
                drift = params["drift"] * i
                noise = RNG.normal(0, params["noise"])
                row[sensor] = round(params["base"] + drift + noise, 4)
            records.append(row)

        df = pd.DataFrame(records)

        # Inject fault events
        if inject_faults > 0:
            fault_idx = RNG.choice(n_hours, inject_faults, replace=False)
            df.loc[fault_idx, "temperature"] += RNG.uniform(8, 20, inject_faults)
            df.loc[fault_idx, "vibration"] *= RNG.uniform(5, 15, inject_faults)
            df.loc[fault_idx, "fault"] = True
            df["fault"] = df["fault"].fillna(False)

        logger.debug("IoT sensor data generated", rows=len(df))
        return df

    # ── Operational Metrics ────────────────────────────────────────────────────

    @staticmethod
    def operational_metrics(
        n_days: int = 90,
        services: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        """
        Simulate operational metrics: latency, error rates, throughput.
        """
        services = services or ["api_gateway", "ml_inference", "data_pipeline", "dashboard"]
        start = datetime(2024, 1, 1, tzinfo=timezone.utc)

        records: List[dict] = []
        for day in range(n_days):
            ts = start + timedelta(days=day)
            for service in services:
                throughput = int(RNG.integers(5_000, 50_000))
                error_rate = float(RNG.uniform(0.001, 0.03))
                latency_p50 = float(RNG.uniform(10, 100))
                latency_p99 = latency_p50 * RNG.uniform(3, 10)

                # Simulate occasional incidents
                incident = RNG.random() < 0.05
                if incident:
                    error_rate *= 10
                    latency_p99 *= 5

                records.append({
                    "timestamp": ts,
                    "service": service,
                    "throughput_rps": throughput,
                    "error_rate": round(error_rate, 5),
                    "latency_p50_ms": round(latency_p50, 2),
                    "latency_p99_ms": round(latency_p99, 2),
                    "uptime_pct": round(RNG.uniform(99.0, 100.0), 3),
                    "is_incident": incident,
                })

        return pd.DataFrame(records)

    # ── User Behaviour ─────────────────────────────────────────────────────────

    @staticmethod
    def user_events(
        n_users: int = 1_000,
        n_days: int = 60,
    ) -> pd.DataFrame:
        """Simulate user event stream for cohort and funnel analysis."""
        stages = ["signup", "onboarding", "first_trade", "active_trader", "premium"]
        stage_probs = [1.0, 0.75, 0.50, 0.30, 0.10]
        start = datetime(2024, 1, 1, tzinfo=timezone.utc)

        records: List[dict] = []
        for user_id in range(1, n_users + 1):
            signup_day = int(RNG.integers(0, n_days))
            user_stage = "signup"
            for stage, prob in zip(stages, stage_probs):
                if RNG.random() <= prob:
                    user_stage = stage
                    event_day = signup_day + int(RNG.integers(0, 10))
                    records.append({
                        "user_id": f"USR_{user_id:05d}",
                        "event": stage,
                        "timestamp": start + timedelta(days=event_day),
                        "session_minutes": round(float(RNG.uniform(1, 45)), 1),
                    })

        return pd.DataFrame(records).sort_values("timestamp").reset_index(drop=True)
