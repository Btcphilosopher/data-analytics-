"""
AUREUM ANALYTICS — Pipeline Engine
Composable, async-capable pipeline execution with
YAML/JSON configuration, step chaining, and structured run reports.
"""

from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Union

import pandas as pd
from pydantic import BaseModel

from aureum_analytics.config import get_logger

logger = get_logger(__name__)

# ── Step Type Aliases ─────────────────────────────────────────────────────────

SyncStep = Callable[[pd.DataFrame], pd.DataFrame]
AsyncStep = Callable[[pd.DataFrame], "Awaitable[pd.DataFrame]"]
PipelineStep = Union[SyncStep, AsyncStep]


class StepResult(BaseModel):
    """Execution record for a single pipeline step."""

    step_name: str
    step_index: int
    status: str  # success | failed | skipped
    input_rows: int
    output_rows: int
    duration_ms: float
    error: Optional[str] = None


class PipelineReport(BaseModel):
    """Full execution report for a pipeline run."""

    pipeline_name: str
    run_id: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str = "running"
    steps: List[StepResult] = []
    total_duration_ms: float = 0.0
    error: Optional[str] = None

    def summary(self) -> str:
        lines = [
            f"PIPELINE: {self.pipeline_name}  RUN: {self.run_id}",
            f"STATUS:   {self.status.upper()}",
            f"DURATION: {self.total_duration_ms:.1f} ms",
            f"STEPS:    {len(self.steps)}",
        ]
        for s in self.steps:
            flag = "✓" if s.status == "success" else "✗"
            lines.append(
                f"  {flag} [{s.step_index:02d}] {s.step_name:<30} "
                f"{s.input_rows:>6} → {s.output_rows:<6} rows  {s.duration_ms:.1f}ms"
            )
        return "\n".join(lines)


class PipelineStep:
    """Declarative step definition with metadata."""

    def __init__(
        self,
        name: str,
        fn: PipelineStep,
        enabled: bool = True,
        on_error: str = "raise",  # raise | skip | continue
    ) -> None:
        self.name = name
        self.fn = fn
        self.enabled = enabled
        self.on_error = on_error


class Pipeline:
    """
    Async-capable data pipeline with composable steps.

    Usage:
        pipeline = Pipeline("financial_etl")
        pipeline.add_step("clean", cleaner_fn)
        pipeline.add_step("normalise", normaliser_fn)
        result_df, report = await pipeline.run(input_df)
    """

    def __init__(self, name: str) -> None:
        self.name = name
        self._steps: List[PipelineStep] = []

    def add_step(
        self,
        name: str,
        fn: Union[SyncStep, AsyncStep],
        enabled: bool = True,
        on_error: str = "raise",
    ) -> "Pipeline":
        """Append a step to the pipeline. Returns self for chaining."""
        self._steps.append(PipelineStep(name, fn, enabled, on_error))
        logger.debug("Step added", pipeline=self.name, step=name)
        return self

    def remove_step(self, name: str) -> "Pipeline":
        self._steps = [s for s in self._steps if s.name != name]
        return self

    async def run(
        self,
        df: pd.DataFrame,
        run_id: Optional[str] = None,
    ) -> tuple[pd.DataFrame, PipelineReport]:
        """
        Execute all pipeline steps sequentially.
        Returns (output_df, report).
        """
        import uuid
        run_id = run_id or str(uuid.uuid4())[:8]
        t_start = time.perf_counter()

        report = PipelineReport(
            pipeline_name=self.name,
            run_id=run_id,
            started_at=datetime.now(timezone.utc),
        )

        logger.info(
            "Pipeline started",
            pipeline=self.name,
            run_id=run_id,
            steps=len(self._steps),
            input_rows=len(df),
        )

        current_df = df.copy()

        for idx, step in enumerate(self._steps):
            if not step.enabled:
                report.steps.append(StepResult(
                    step_name=step.name,
                    step_index=idx,
                    status="skipped",
                    input_rows=len(current_df),
                    output_rows=len(current_df),
                    duration_ms=0.0,
                ))
                continue

            t_step = time.perf_counter()
            input_rows = len(current_df)

            try:
                if asyncio.iscoroutinefunction(step.fn):
                    current_df = await step.fn(current_df)
                else:
                    current_df = step.fn(current_df)

                duration = (time.perf_counter() - t_step) * 1000
                report.steps.append(StepResult(
                    step_name=step.name,
                    step_index=idx,
                    status="success",
                    input_rows=input_rows,
                    output_rows=len(current_df),
                    duration_ms=duration,
                ))
                logger.debug(
                    "Step complete",
                    step=step.name,
                    rows=len(current_df),
                    ms=f"{duration:.1f}",
                )

            except Exception as exc:
                duration = (time.perf_counter() - t_step) * 1000
                report.steps.append(StepResult(
                    step_name=step.name,
                    step_index=idx,
                    status="failed",
                    input_rows=input_rows,
                    output_rows=0,
                    duration_ms=duration,
                    error=str(exc),
                ))
                logger.error(
                    "Pipeline step failed",
                    pipeline=self.name,
                    step=step.name,
                    error=str(exc),
                )
                if step.on_error == "raise":
                    report.status = "failed"
                    report.error = f"Step '{step.name}' failed: {exc}"
                    report.completed_at = datetime.now(timezone.utc)
                    report.total_duration_ms = (time.perf_counter() - t_start) * 1000
                    raise
                elif step.on_error == "skip":
                    continue
                # "continue" — pass through unchanged df

        report.status = "complete"
        report.completed_at = datetime.now(timezone.utc)
        report.total_duration_ms = (time.perf_counter() - t_start) * 1000

        logger.info(
            "Pipeline complete",
            pipeline=self.name,
            run_id=run_id,
            output_rows=len(current_df),
            duration_ms=f"{report.total_duration_ms:.1f}",
        )
        return current_df, report

    def run_sync(
        self,
        df: pd.DataFrame,
        run_id: Optional[str] = None,
    ) -> tuple[pd.DataFrame, PipelineReport]:
        """Blocking wrapper for synchronous callers."""
        return asyncio.get_event_loop().run_until_complete(self.run(df, run_id))

    def __len__(self) -> int:
        return len(self._steps)

    def __repr__(self) -> str:
        return f"<Pipeline(name={self.name!r}, steps={len(self._steps)})>"
