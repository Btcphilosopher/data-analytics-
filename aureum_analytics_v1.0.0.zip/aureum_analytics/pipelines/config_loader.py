"""
AUREUM ANALYTICS — Pipeline Config Loader
Parses YAML/JSON pipeline definitions and resolves
step functions from the AUREUM component registry.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import yaml
from pydantic import BaseModel

from aureum_analytics.config import get_logger
from aureum_analytics.pipelines.pipeline_engine import Pipeline
from aureum_analytics.preprocessing.cleaning import DataCleaner
from aureum_analytics.preprocessing.transformation import Transformer
from aureum_analytics.preprocessing.feature_engineering import FeatureEngineer

logger = get_logger(__name__)


class StepConfig(BaseModel):
    name: str
    type: str
    params: Dict[str, Any] = {}
    enabled: bool = True
    on_error: str = "raise"


class PipelineConfig(BaseModel):
    name: str
    description: Optional[str] = None
    version: str = "1.0.0"
    steps: List[StepConfig]


# ── Step Function Registry ────────────────────────────────────────────────────

def _make_clean_step(params: Dict[str, Any]) -> Callable:
    def step(df):
        result, _ = DataCleaner.clean(
            df,
            drop_dups=params.get("drop_duplicates", True),
            null_strategy=params.get("null_strategy", "drop"),
            outlier_columns=params.get("outlier_columns"),
            dtype_schema=params.get("dtype_schema"),
        )
        return result
    step.__name__ = "clean"
    return step


def _make_normalise_step(params: Dict[str, Any]) -> Callable:
    transformer = Transformer()
    fitted = False

    def step(df):
        nonlocal fitted
        columns = params.get("columns", df.select_dtypes(include="number").columns.tolist())
        method = params.get("method", "standard")
        if not fitted:
            transformer.fit_scaler(df, columns, method)
            fitted = True
        return transformer.transform_scale(df, method)

    step.__name__ = "normalise"
    return step


def _make_rolling_mean_step(params: Dict[str, Any]) -> Callable:
    def step(df):
        column = params["column"]
        windows = params.get("windows", [7, 14, 30])
        return FeatureEngineer.rolling_mean(df, column, windows)
    step.__name__ = "rolling_mean"
    return step


def _make_lag_features_step(params: Dict[str, Any]) -> Callable:
    def step(df):
        column = params["column"]
        lags = params.get("lags", [1, 2, 3, 7])
        return FeatureEngineer.lag_features(df, column, lags)
    step.__name__ = "lag_features"
    return step


def _make_temporal_features_step(params: Dict[str, Any]) -> Callable:
    def step(df):
        column = params["timestamp_column"]
        return FeatureEngineer.temporal_features(df, column)
    step.__name__ = "temporal_features"
    return step


def _make_resample_step(params: Dict[str, Any]) -> Callable:
    def step(df):
        return Transformer.resample_timeseries(
            df,
            timestamp_col=params["timestamp_column"],
            frequency=params.get("frequency", "1H"),
            agg_func=params.get("agg_func", "mean"),
        )
    step.__name__ = "resample"
    return step


STEP_REGISTRY: Dict[str, Callable[[Dict[str, Any]], Callable]] = {
    "clean": _make_clean_step,
    "normalise": _make_normalise_step,
    "normalize": _make_normalise_step,
    "rolling_mean": _make_rolling_mean_step,
    "lag_features": _make_lag_features_step,
    "temporal_features": _make_temporal_features_step,
    "resample": _make_resample_step,
}


class ConfigLoader:
    """
    Deserialises YAML/JSON pipeline configs and constructs
    executable Pipeline objects from the step registry.
    """

    @staticmethod
    def from_file(path: str) -> Pipeline:
        """Load a pipeline definition from a YAML or JSON file."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Pipeline config not found: {path}")

        with open(p) as f:
            if p.suffix in (".yml", ".yaml"):
                raw = yaml.safe_load(f)
            else:
                raw = json.load(f)

        return ConfigLoader.from_dict(raw)

    @staticmethod
    def from_dict(raw: Dict[str, Any]) -> Pipeline:
        """Construct a Pipeline from a raw config dictionary."""
        pipeline_raw = raw.get("pipeline", raw)
        config = PipelineConfig(**pipeline_raw)
        pipeline = Pipeline(config.name)

        for step_cfg in config.steps:
            builder = STEP_REGISTRY.get(step_cfg.type)
            if builder is None:
                logger.warning(
                    "Unknown step type — skipping",
                    step=step_cfg.name,
                    type=step_cfg.type,
                )
                continue

            fn = builder(step_cfg.params)
            pipeline.add_step(
                name=step_cfg.name,
                fn=fn,
                enabled=step_cfg.enabled,
                on_error=step_cfg.on_error,
            )

        logger.info(
            "Pipeline loaded from config",
            name=config.name,
            steps=len(pipeline),
        )
        return pipeline
