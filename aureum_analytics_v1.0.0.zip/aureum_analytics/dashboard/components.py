"""
AUREUM ANALYTICS — Dashboard Components
Reusable Plotly figure factories.
All charts share the Anglo-futurist visual language:
dark backgrounds, gold/cyan signals, no grid noise.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# ── Shared theme constants ────────────────────────────────────────────────────
_BG = "#0d1220"
_GRID = "#1a2235"
_GOLD = "#c9a84c"
_CYAN = "#00d4e0"
_RED = "#e05252"
_GREEN = "#4ecb71"
_ORANGE = "#e0a852"
_WHITE = "#e8ecf4"
_MUTED = "#6b7a99"
_MONO = "'DM Mono', monospace"

_BASE_LAYOUT = dict(
    paper_bgcolor=_BG,
    plot_bgcolor=_BG,
    font=dict(family=_MONO, color=_MUTED, size=10),
    margin=dict(l=48, r=16, t=16, b=36),
    xaxis=dict(
        gridcolor=_GRID,
        zeroline=False,
        showline=False,
        tickfont=dict(family=_MONO, size=9, color=_MUTED),
    ),
    yaxis=dict(
        gridcolor=_GRID,
        zeroline=False,
        showline=False,
        tickfont=dict(family=_MONO, size=9, color=_MUTED),
    ),
    legend=dict(
        bgcolor="rgba(0,0,0,0)",
        bordercolor=_GRID,
        borderwidth=1,
        font=dict(family=_MONO, size=9, color=_MUTED),
    ),
    hovermode="x unified",
    hoverlabel=dict(
        bgcolor="#111827",
        bordercolor=_GRID,
        font=dict(family=_MONO, size=10, color=_WHITE),
    ),
)


def _apply_base(fig: go.Figure) -> go.Figure:
    fig.update_layout(**_BASE_LAYOUT)
    return fig


# ── Chart Factories ───────────────────────────────────────────────────────────

def price_volume_chart(df: pd.DataFrame) -> go.Figure:
    """
    Dual-panel OHLCV candlestick chart with volume bars.
    Anomalous points marked with gold diamond markers.
    """
    fig = make_subplots(
        rows=2, cols=1,
        row_heights=[0.75, 0.25],
        shared_xaxes=True,
        vertical_spacing=0.02,
    )

    # Candlestick
    fig.add_trace(
        go.Candlestick(
            x=df["timestamp"],
            open=df.get("open", df["close"]),
            high=df.get("high", df["close"]),
            low=df.get("low", df["close"]),
            close=df["close"],
            name="OHLC",
            increasing=dict(line=dict(color=_GREEN, width=1), fillcolor=_GREEN),
            decreasing=dict(line=dict(color=_RED, width=1), fillcolor=_RED),
        ),
        row=1, col=1,
    )

    # Anomaly markers
    if "anomaly" in df.columns:
        anomalies = df[df["anomaly"] == True]
        if len(anomalies):
            fig.add_trace(
                go.Scatter(
                    x=anomalies["timestamp"],
                    y=anomalies["close"],
                    mode="markers",
                    name="ANOMALY",
                    marker=dict(
                        symbol="diamond",
                        color=_GOLD,
                        size=10,
                        line=dict(color=_BG, width=1),
                    ),
                ),
                row=1, col=1,
            )

    # Volume bars
    colors = [_GREEN if c >= o else _RED
              for c, o in zip(df["close"], df.get("open", df["close"]))]
    fig.add_trace(
        go.Bar(
            x=df["timestamp"],
            y=df["volume"],
            name="VOLUME",
            marker=dict(color=colors, opacity=0.6),
        ),
        row=2, col=1,
    )

    fig.update_layout(**_BASE_LAYOUT)
    fig.update_yaxes(gridcolor=_GRID, zeroline=False, showline=False)
    fig.update_xaxes(rangeslider_visible=False)
    return fig


def forecast_chart(
    historical: pd.DataFrame,
    forecast_df: pd.DataFrame,
) -> go.Figure:
    """
    Time-series forecast with confidence interval ribbon.
    Historical line in cyan, forecast in gold, CI in transparent gold.
    """
    fig = go.Figure()

    # Historical
    fig.add_trace(go.Scatter(
        x=historical["timestamp"],
        y=historical["close"],
        name="HISTORICAL",
        line=dict(color=_CYAN, width=1.5),
        mode="lines",
    ))

    # Confidence interval
    if "upper_bound" in forecast_df.columns and "lower_bound" in forecast_df.columns:
        fig.add_trace(go.Scatter(
            x=list(forecast_df["timestamp"]) + list(forecast_df["timestamp"])[::-1],
            y=list(forecast_df["upper_bound"]) + list(forecast_df["lower_bound"])[::-1],
            fill="toself",
            fillcolor=f"rgba(201,168,76,0.12)",
            line=dict(color="rgba(0,0,0,0)"),
            name="95% CI",
            hoverinfo="skip",
        ))

    # Forecast line
    fig.add_trace(go.Scatter(
        x=forecast_df["timestamp"],
        y=forecast_df["forecast"],
        name="FORECAST",
        line=dict(color=_GOLD, width=2, dash="dot"),
        mode="lines",
    ))

    return _apply_base(fig)


def anomaly_scatter(df: pd.DataFrame, value_col: str = "close") -> go.Figure:
    """
    Scatter plot with anomaly scores as colour dimension.
    Detected anomalies rendered in gold, normal in cyan/muted.
    """
    fig = go.Figure()

    normal = df[df.get("is_anomaly", pd.Series(False, index=df.index)) == False] if "is_anomaly" in df.columns else df
    anomalous = df[df.get("is_anomaly", pd.Series(False, index=df.index)) == True] if "is_anomaly" in df.columns else pd.DataFrame()

    fig.add_trace(go.Scatter(
        x=normal.get("timestamp", normal.index),
        y=normal[value_col] if value_col in normal.columns else normal.iloc[:, 0],
        mode="markers",
        name="NORMAL",
        marker=dict(color=_CYAN, size=4, opacity=0.5),
    ))

    if len(anomalous):
        fig.add_trace(go.Scatter(
            x=anomalous.get("timestamp", anomalous.index),
            y=anomalous[value_col] if value_col in anomalous.columns else anomalous.iloc[:, 0],
            mode="markers",
            name="ANOMALY",
            marker=dict(
                color=_GOLD,
                size=10,
                symbol="diamond",
                line=dict(color=_BG, width=1),
            ),
        ))

    return _apply_base(fig)


def operational_metrics_chart(df: pd.DataFrame) -> go.Figure:
    """
    Multi-line operational metrics chart.
    Latency p99, error rate, and throughput on a single panel.
    """
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Latency
    fig.add_trace(
        go.Scatter(
            x=df["timestamp"],
            y=df["latency_p99_ms"],
            name="LATENCY P99",
            line=dict(color=_ORANGE, width=1.5),
            mode="lines",
        ),
        secondary_y=False,
    )

    # Error rate (secondary axis)
    fig.add_trace(
        go.Scatter(
            x=df["timestamp"],
            y=df["error_rate"] * 100,
            name="ERROR RATE %",
            line=dict(color=_RED, width=1, dash="dot"),
            mode="lines",
        ),
        secondary_y=True,
    )

    fig.update_layout(**_BASE_LAYOUT)
    fig.update_yaxes(
        title_text="LATENCY (MS)",
        title_font=dict(family=_MONO, size=9, color=_MUTED),
        gridcolor=_GRID,
        secondary_y=False,
    )
    fig.update_yaxes(
        title_text="ERROR RATE (%)",
        title_font=dict(family=_MONO, size=9, color=_MUTED),
        gridcolor=_GRID,
        secondary_y=True,
    )
    return fig


def empty_figure(message: str = "AWAITING DATA") -> go.Figure:
    """Placeholder figure with status message."""
    fig = go.Figure()
    fig.update_layout(
        **_BASE_LAYOUT,
        annotations=[dict(
            text=message,
            x=0.5, y=0.5,
            xref="paper", yref="paper",
            showarrow=False,
            font=dict(family=_MONO, size=12, color=_MUTED),
        )],
    )
    return fig
