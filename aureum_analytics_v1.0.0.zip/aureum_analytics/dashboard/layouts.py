"""
AUREUM ANALYTICS — Dashboard Layouts
Composable layout system. Anglo-futurist: dark navy/gold/cyan,
data-dense panels, minimal chrome, zero decorative noise.
"""

from __future__ import annotations

from dash import dcc, html

from aureum_analytics.config import settings

# ── Design Tokens ─────────────────────────────────────────────────────────────
PALETTE = {
    "bg_deep": "#060912",
    "bg_panel": "#0d1220",
    "bg_card": "#111827",
    "border": "#1e2d45",
    "gold": "#c9a84c",
    "gold_dim": "#8a6f2e",
    "cyan": "#00d4e0",
    "cyan_dim": "#007a85",
    "white": "#e8ecf4",
    "muted": "#6b7a99",
    "danger": "#e05252",
    "success": "#4ecb71",
    "warning": "#e0a852",
    "grid": "#141e30",
}

FONTS = {
    "heading": "'Bebas Neue', 'Impact', sans-serif",
    "mono": "'DM Mono', 'Consolas', 'Courier New', monospace",
    "body": "'Inter', 'Segoe UI', sans-serif",
}

CARD_STYLE = {
    "backgroundColor": PALETTE["bg_card"],
    "border": f"1px solid {PALETTE['border']}",
    "borderRadius": "2px",
    "padding": "16px 20px",
}

LABEL_STYLE = {
    "fontFamily": FONTS["mono"],
    "fontSize": "10px",
    "letterSpacing": "0.12em",
    "color": PALETTE["muted"],
    "textTransform": "uppercase",
    "marginBottom": "4px",
}

VALUE_STYLE = {
    "fontFamily": FONTS["heading"],
    "fontSize": "28px",
    "letterSpacing": "0.04em",
    "color": PALETTE["gold"],
    "lineHeight": "1",
}


# ── Component Builders ────────────────────────────────────────────────────────

def kpi_card(
    card_id: str,
    label: str,
    unit: str = "",
    accent: str = PALETTE["gold"],
) -> html.Div:
    """Single KPI readout card."""
    return html.Div(
        style={**CARD_STYLE, "minWidth": "160px", "flex": "1"},
        children=[
            html.Div(label, style=LABEL_STYLE),
            html.Div(
                id=card_id,
                children="—",
                style={**VALUE_STYLE, "color": accent},
            ),
            html.Div(unit, style={**LABEL_STYLE, "marginTop": "4px", "marginBottom": 0}),
        ],
    )


def section_header(title: str, subtitle: str = "") -> html.Div:
    """Horizontal section divider with title."""
    return html.Div(
        style={
            "borderBottom": f"1px solid {PALETTE['border']}",
            "paddingBottom": "8px",
            "marginBottom": "16px",
            "marginTop": "24px",
        },
        children=[
            html.Span(title, style={
                "fontFamily": FONTS["heading"],
                "fontSize": "13px",
                "letterSpacing": "0.18em",
                "color": PALETTE["cyan"],
                "textTransform": "uppercase",
            }),
            html.Span(f"  //  {subtitle}", style={
                "fontFamily": FONTS["mono"],
                "fontSize": "10px",
                "color": PALETTE["muted"],
            }) if subtitle else html.Span(),
        ],
    )


def build_layout() -> html.Div:
    """Construct the full AUREUM dashboard layout."""
    return html.Div(
        style={
            "backgroundColor": PALETTE["bg_deep"],
            "minHeight": "100vh",
            "fontFamily": FONTS["body"],
            "color": PALETTE["white"],
        },
        children=[
            # ── Google Fonts ──────────────────────────────────────────────────
            html.Link(
                rel="stylesheet",
                href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@400;500&family=Inter:wght@400;500&display=swap",
            ),

            # ── Header Bar ────────────────────────────────────────────────────
            html.Div(
                style={
                    "backgroundColor": PALETTE["bg_panel"],
                    "borderBottom": f"1px solid {PALETTE['border']}",
                    "padding": "0 32px",
                    "height": "52px",
                    "display": "flex",
                    "alignItems": "center",
                    "justifyContent": "space-between",
                    "position": "sticky",
                    "top": "0",
                    "zIndex": "100",
                },
                children=[
                    html.Div(
                        style={"display": "flex", "alignItems": "center", "gap": "12px"},
                        children=[
                            html.Div("▣", style={
                                "color": PALETTE["gold"],
                                "fontSize": "20px",
                            }),
                            html.Span("AUREUM ANALYTICS", style={
                                "fontFamily": FONTS["heading"],
                                "fontSize": "18px",
                                "letterSpacing": "0.24em",
                                "color": PALETTE["white"],
                            }),
                            html.Span("v1.0.0", style={
                                "fontFamily": FONTS["mono"],
                                "fontSize": "10px",
                                "color": PALETTE["muted"],
                                "marginLeft": "4px",
                            }),
                        ],
                    ),
                    html.Div(
                        style={"display": "flex", "alignItems": "center", "gap": "24px"},
                        children=[
                            html.Div(id="header-timestamp", style={
                                "fontFamily": FONTS["mono"],
                                "fontSize": "11px",
                                "color": PALETTE["muted"],
                            }),
                            html.Div(
                                style={"display": "flex", "alignItems": "center", "gap": "6px"},
                                children=[
                                    html.Div(style={
                                        "width": "6px",
                                        "height": "6px",
                                        "borderRadius": "50%",
                                        "backgroundColor": PALETTE["success"],
                                    }),
                                    html.Span("LIVE", style={
                                        "fontFamily": FONTS["mono"],
                                        "fontSize": "10px",
                                        "letterSpacing": "0.12em",
                                        "color": PALETTE["success"],
                                    }),
                                ],
                            ),
                        ],
                    ),
                ],
            ),

            # ── Main Body ─────────────────────────────────────────────────────
            html.Div(
                style={"padding": "24px 32px"},
                children=[

                    # ── KPI Row ───────────────────────────────────────────────
                    section_header("SYSTEM TELEMETRY", "real-time KPIs"),
                    html.Div(
                        style={
                            "display": "flex",
                            "gap": "12px",
                            "flexWrap": "wrap",
                            "marginBottom": "24px",
                        },
                        children=[
                            kpi_card("kpi-price", "LAST PRICE", "USD"),
                            kpi_card("kpi-volume", "VOLUME", "24H", PALETTE["cyan"]),
                            kpi_card("kpi-anomalies", "ANOMALIES", "ACTIVE", PALETTE["danger"]),
                            kpi_card("kpi-latency", "API LATENCY", "MS", PALETTE["warning"]),
                            kpi_card("kpi-models", "MODELS", "LOADED", PALETTE["success"]),
                        ],
                    ),

                    # ── Price Chart ───────────────────────────────────────────
                    section_header("MARKET SIGNAL", "price & volume time-series"),
                    html.Div(
                        style=CARD_STYLE,
                        children=[
                            dcc.Graph(
                                id="chart-price",
                                config={"displayModeBar": False, "scrollZoom": True},
                                style={"height": "320px"},
                            ),
                        ],
                    ),

                    # ── Mid Row: Forecast + Anomaly ───────────────────────────
                    html.Div(
                        style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "16px", "marginTop": "16px"},
                        children=[
                            html.Div(
                                style=CARD_STYLE,
                                children=[
                                    section_header("FORECAST", "30-day projection"),
                                    dcc.Graph(
                                        id="chart-forecast",
                                        config={"displayModeBar": False},
                                        style={"height": "260px"},
                                    ),
                                ],
                            ),
                            html.Div(
                                style=CARD_STYLE,
                                children=[
                                    section_header("ANOMALY SCANNER", "isolation forest"),
                                    dcc.Graph(
                                        id="chart-anomaly",
                                        config={"displayModeBar": False},
                                        style={"height": "260px"},
                                    ),
                                ],
                            ),
                        ],
                    ),

                    # ── Bottom Row: Operational + Alert Log ───────────────────
                    html.Div(
                        style={"display": "grid", "gridTemplateColumns": "2fr 1fr", "gap": "16px", "marginTop": "16px"},
                        children=[
                            html.Div(
                                style=CARD_STYLE,
                                children=[
                                    section_header("OPERATIONAL METRICS", "latency · throughput · error rate"),
                                    dcc.Graph(
                                        id="chart-operational",
                                        config={"displayModeBar": False},
                                        style={"height": "240px"},
                                    ),
                                ],
                            ),
                            html.Div(
                                style=CARD_STYLE,
                                children=[
                                    section_header("ALERT LOG", "active signals"),
                                    html.Div(
                                        id="alert-log",
                                        style={
                                            "height": "240px",
                                            "overflowY": "auto",
                                            "fontFamily": FONTS["mono"],
                                            "fontSize": "11px",
                                        },
                                        children=[html.Div("— no active alerts —", style={"color": PALETTE["muted"]})],
                                    ),
                                ],
                            ),
                        ],
                    ),

                    # ── Pipeline Status ───────────────────────────────────────
                    html.Div(style={"marginTop": "16px"}, children=[
                        section_header("PIPELINE REGISTRY", "execution status"),
                        html.Div(id="pipeline-status", style={**CARD_STYLE}),
                    ]),

                ],
            ),

            # ── Live update interval ──────────────────────────────────────────
            dcc.Interval(
                id="interval-live",
                interval=settings.DASHBOARD_REFRESH_INTERVAL,
                n_intervals=0,
            ),
        ],
    )
