"""
AUREUM ANALYTICS — Dashboard Application
Plotly Dash real-time analytics dashboard.
Anglo-futurist design: dark, precise, data-dense, minimal animation.
"""

from __future__ import annotations

import dash
from dash import Dash

from aureum_analytics.config import settings

# ── Initialise Dash ───────────────────────────────────────────────────────────
app = Dash(
    __name__,
    title="AUREUM ANALYTICS",
    update_title=None,
    suppress_callback_exceptions=True,
    meta_tags=[
        {"name": "viewport", "content": "width=device-width, initial-scale=1"},
        {"name": "theme-color", "content": "#0a0d14"},
    ],
)
server = app.server  # Flask server for production WSGI deployment


def run_dashboard() -> None:
    """Launch the AUREUM dashboard in development mode."""
    from aureum_analytics.dashboard.layouts import build_layout
    from aureum_analytics.dashboard import callbacks  # noqa: F401 — registers callbacks

    app.layout = build_layout()
    app.run(
        host=settings.DASHBOARD_HOST,
        port=settings.DASHBOARD_PORT,
        debug=settings.DEBUG,
    )
