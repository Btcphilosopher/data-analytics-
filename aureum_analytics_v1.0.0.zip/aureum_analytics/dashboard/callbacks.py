"""
AUREUM ANALYTICS — Dashboard Callbacks
All Dash reactive callbacks for live data updates.
Each callback is pure: input → output, no side effects.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, List, Tuple

import pandas as pd
from dash import Input, Output, callback
from dash import html

from aureum_analytics.alerts.alert_engine import alert_engine, AlertPriority
from aureum_analytics.analytics.aggregation import MetricsCalculator
from aureum_analytics.dashboard.components import (
    anomaly_scatter,
    empty_figure,
    forecast_chart,
    operational_metrics_chart,
    price_volume_chart,
)
from aureum_analytics.mock.data_generator import MockDataGenerator

# ── Colour palette (must match layouts.py) ────────────────────────────────────
_GOLD = "#c9a84c"
_CYAN = "#00d4e0"
_RED = "#e05252"
_GREEN = "#4ecb71"
_ORANGE = "#e0a852"
_MUTED = "#6b7a99"
_MONO = "'DM Mono', monospace"

PRIORITY_COLOURS = {
    "CRITICAL": _RED,
    "HIGH": _ORANGE,
    "MEDIUM": _GOLD,
    "LOW": _MUTED,
}


# ── Header timestamp ──────────────────────────────────────────────────────────

@callback(
    Output("header-timestamp", "children"),
    Input("interval-live", "n_intervals"),
)
def update_timestamp(n: int) -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d  %H:%M:%S UTC")


# ── KPI Cards ─────────────────────────────────────────────────────────────────

@callback(
    Output("kpi-price", "children"),
    Output("kpi-volume", "children"),
    Output("kpi-anomalies", "children"),
    Output("kpi-latency", "children"),
    Output("kpi-models", "children"),
    Input("interval-live", "n_intervals"),
)
def update_kpis(n: int) -> Tuple[str, str, str, str, str]:
    import random

    df = MockDataGenerator.financial_timeseries(n_days=7)
    last_price = f"{df['close'].iloc[-1]:,.2f}"
    total_volume = f"{int(df['volume'].sum()):,}"
    active_alerts = str(len(alert_engine.get_active_alerts()))
    latency = f"{random.uniform(8.0, 45.0):.1f}"
    models = "4"

    return last_price, total_volume, active_alerts, latency, models


# ── Price Chart ───────────────────────────────────────────────────────────────

@callback(
    Output("chart-price", "figure"),
    Input("interval-live", "n_intervals"),
)
def update_price_chart(n: int) -> Any:
    try:
        df = MockDataGenerator.financial_timeseries(n_days=90)
        return price_volume_chart(df)
    except Exception:
        return empty_figure("PRICE DATA UNAVAILABLE")


# ── Forecast Chart ────────────────────────────────────────────────────────────

@callback(
    Output("chart-forecast", "figure"),
    Input("interval-live", "n_intervals"),
)
def update_forecast_chart(n: int) -> Any:
    try:
        import numpy as np

        historical = MockDataGenerator.financial_timeseries(n_days=60)
        last_price = historical["close"].iloc[-1]
        last_date = historical["timestamp"].iloc[-1]

        # Lightweight mock forecast (avoids full model training on each tick)
        steps = 30
        rng = __import__("numpy").random.default_rng(n % 100)
        mu, sigma = 0.0003, 0.016
        log_returns = rng.normal(mu, sigma, steps)
        fcast_prices = last_price * np.exp(np.cumsum(log_returns))
        std = sigma * last_price
        z = 1.96
        lower = fcast_prices - z * std * np.sqrt(np.arange(1, steps + 1))
        upper = fcast_prices + z * std * np.sqrt(np.arange(1, steps + 1))

        dates = pd.date_range(start=last_date, periods=steps + 1, freq="D")[1:]
        forecast_df = pd.DataFrame({
            "timestamp": dates,
            "forecast": fcast_prices,
            "lower_bound": lower,
            "upper_bound": upper,
        })
        return forecast_chart(historical.tail(30), forecast_df)
    except Exception:
        return empty_figure("FORECAST UNAVAILABLE")


# ── Anomaly Chart ─────────────────────────────────────────────────────────────

@callback(
    Output("chart-anomaly", "figure"),
    Input("interval-live", "n_intervals"),
)
def update_anomaly_chart(n: int) -> Any:
    try:
        from aureum_analytics.ml.models.anomaly import ZScoreAnomalyDetector

        df = MockDataGenerator.financial_timeseries(n_days=90)
        detector = ZScoreAnomalyDetector(threshold=2.8)
        result = detector.detect(df, columns=["close", "volume"])
        return anomaly_scatter(result, value_col="close")
    except Exception:
        return empty_figure("ANOMALY DATA UNAVAILABLE")


# ── Operational Metrics Chart ─────────────────────────────────────────────────

@callback(
    Output("chart-operational", "figure"),
    Input("interval-live", "n_intervals"),
)
def update_operational_chart(n: int) -> Any:
    try:
        df = MockDataGenerator.operational_metrics(n_days=30, services=["api_gateway"])
        return operational_metrics_chart(df)
    except Exception:
        return empty_figure("OPERATIONAL DATA UNAVAILABLE")


# ── Alert Log ─────────────────────────────────────────────────────────────────

@callback(
    Output("alert-log", "children"),
    Input("interval-live", "n_intervals"),
)
def update_alert_log(n: int) -> List[Any]:
    alerts = alert_engine.get_history(limit=20)
    if not alerts:
        return [html.Div("— no alerts —", style={"color": _MUTED, "padding": "8px 0"})]

    rows = []
    for alert in reversed(alerts[-15:]):
        colour = PRIORITY_COLOURS.get(alert.priority.value, _MUTED)
        rows.append(html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "70px 65px 1fr",
                "gap": "8px",
                "padding": "6px 0",
                "borderBottom": "1px solid #1a2235",
                "alignItems": "center",
            },
            children=[
                html.Span(
                    alert.triggered_at.strftime("%H:%M:%S"),
                    style={"color": _MUTED, "fontSize": "10px"},
                ),
                html.Span(
                    alert.priority.value,
                    style={"color": colour, "fontSize": "10px", "fontWeight": "500"},
                ),
                html.Span(
                    alert.title,
                    style={"color": "#c8d0e0", "fontSize": "10px", "overflow": "hidden",
                           "textOverflow": "ellipsis", "whiteSpace": "nowrap"},
                ),
            ],
        ))
    return rows


# ── Pipeline Status Panel ─────────────────────────────────────────────────────

@callback(
    Output("pipeline-status", "children"),
    Input("interval-live", "n_intervals"),
)
def update_pipeline_status(n: int) -> Any:
    pipelines = [
        {"name": "financial_preprocessing", "status": "ACTIVE", "last_run": "00:00:02", "rows": "365"},
        {"name": "iot_sensor_pipeline", "status": "ACTIVE", "last_run": "00:00:05", "rows": "720"},
        {"name": "anomaly_detector", "status": "ACTIVE", "last_run": "00:00:08", "rows": "90"},
        {"name": "forecast_engine", "status": "ACTIVE", "last_run": "00:00:30", "rows": "60"},
    ]

    header = html.Div(
        style={
            "display": "grid",
            "gridTemplateColumns": "1fr 90px 100px 80px",
            "gap": "16px",
            "padding": "4px 0 8px 0",
            "borderBottom": "1px solid #1a2235",
            "marginBottom": "8px",
        },
        children=[
            html.Span("PIPELINE", style={"color": _MUTED, "fontSize": "9px", "letterSpacing": "0.12em"}),
            html.Span("STATUS", style={"color": _MUTED, "fontSize": "9px", "letterSpacing": "0.12em"}),
            html.Span("LAST RUN", style={"color": _MUTED, "fontSize": "9px", "letterSpacing": "0.12em"}),
            html.Span("ROWS", style={"color": _MUTED, "fontSize": "9px", "letterSpacing": "0.12em"}),
        ],
    )

    rows = [header]
    for p in pipelines:
        rows.append(html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "1fr 90px 100px 80px",
                "gap": "16px",
                "padding": "6px 0",
                "borderBottom": "1px solid #111827",
                "fontFamily": _MONO,
                "fontSize": "11px",
            },
            children=[
                html.Span(p["name"], style={"color": "#c8d0e0"}),
                html.Span(p["status"], style={"color": _GREEN}),
                html.Span(f"-{p['last_run']}", style={"color": _MUTED}),
                html.Span(p["rows"], style={"color": _CYAN}),
            ],
        ))
    return rows
