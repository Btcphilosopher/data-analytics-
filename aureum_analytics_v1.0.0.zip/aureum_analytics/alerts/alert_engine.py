"""
AUREUM ANALYTICS — Alerting System
Real-time anomaly alerts with priority scoring,
threshold triggers, and structured alert records.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

import pandas as pd
from pydantic import BaseModel

from aureum_analytics.config import get_logger, settings
from aureum_analytics.streaming.event_bus import AureumEvent, event_bus

logger = get_logger(__name__)


class AlertPriority(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Alert(BaseModel):
    """Structured alert record."""

    alert_id: str
    alert_type: str
    priority: AlertPriority
    source: str
    title: str
    description: str
    value: Optional[float] = None
    threshold: Optional[float] = None
    confidence: Optional[float] = None
    triggered_at: datetime
    resolved_at: Optional[datetime] = None
    resolved: bool = False
    metadata: Dict[str, Any] = {}

    @classmethod
    def create(
        cls,
        alert_type: str,
        priority: AlertPriority,
        source: str,
        title: str,
        description: str,
        value: Optional[float] = None,
        threshold: Optional[float] = None,
        confidence: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "Alert":
        return cls(
            alert_id=str(uuid4())[:8].upper(),
            alert_type=alert_type,
            priority=priority,
            source=source,
            title=title,
            description=description,
            value=value,
            threshold=threshold,
            confidence=confidence,
            triggered_at=datetime.now(timezone.utc),
            metadata=metadata or {},
        )


class ThresholdRule(BaseModel):
    """Configuration for a threshold-based alert rule."""

    name: str
    column: str
    operator: str  # gt | lt | gte | lte | eq | ne
    threshold: float
    priority: AlertPriority = AlertPriority.MEDIUM
    source: str = "threshold_monitor"
    enabled: bool = True

    def evaluate(self, value: float) -> bool:
        ops = {
            "gt": lambda v, t: v > t,
            "lt": lambda v, t: v < t,
            "gte": lambda v, t: v >= t,
            "lte": lambda v, t: v <= t,
            "eq": lambda v, t: v == t,
            "ne": lambda v, t: v != t,
        }
        fn = ops.get(self.operator)
        return fn(value, self.threshold) if fn else False


class AlertEngine:
    """
    Real-time alerting engine.

    Supports:
    - anomaly detection alerts (from ML output)
    - threshold-based rule evaluation
    - priority scoring
    - event bus emission
    - alert history with resolution tracking
    """

    def __init__(self) -> None:
        self._history: List[Alert] = []
        self._rules: List[ThresholdRule] = []
        self._handlers: List[Callable[[Alert], Any]] = []

    def register_rule(self, rule: ThresholdRule) -> None:
        self._rules.append(rule)
        logger.info("Alert rule registered", name=rule.name, column=rule.column)

    def register_handler(self, handler: Callable[[Alert], Any]) -> None:
        self._handlers.append(handler)

    def _score_priority(self, confidence: float) -> AlertPriority:
        """Map anomaly confidence to alert priority."""
        if confidence >= settings.ALERT_PRIORITY_HIGH_THRESHOLD:
            return AlertPriority.CRITICAL
        elif confidence >= settings.ALERT_PRIORITY_MEDIUM_THRESHOLD:
            return AlertPriority.HIGH
        elif confidence >= 0.3:
            return AlertPriority.MEDIUM
        return AlertPriority.LOW

    async def _emit(self, alert: Alert) -> None:
        """Publish alert to event bus and registered handlers."""
        event = AureumEvent.create(
            event_type="ALERT",
            source=alert.source,
            payload=alert.model_dump(mode="json"),
            priority=2 if alert.priority == AlertPriority.CRITICAL else 1,
        )
        await event_bus.publish(settings.ALERT_CHANNEL, event)

        for handler in self._handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(alert)
                else:
                    handler(alert)
            except Exception as exc:
                logger.error("Alert handler error", error=str(exc))

    async def raise_anomaly_alerts(
        self,
        df: pd.DataFrame,
        source: str,
        confidence_col: str = "anomaly_confidence",
        value_col: Optional[str] = None,
    ) -> List[Alert]:
        """
        Convert anomaly detection output rows into structured alerts.
        Expects df to contain 'is_anomaly' and optionally 'anomaly_confidence'.
        """
        alerts: List[Alert] = []
        anomaly_rows = df[df.get("is_anomaly", pd.Series(False)) == True]

        for _, row in anomaly_rows.iterrows():
            confidence = float(row.get(confidence_col, 0.5))
            priority = self._score_priority(confidence)
            value = float(row[value_col]) if value_col and value_col in row else None

            alert = Alert.create(
                alert_type="ANOMALY",
                priority=priority,
                source=source,
                title=f"Anomaly detected [{priority.value}]",
                description=(
                    f"Anomaly signal from '{source}' "
                    f"with confidence {confidence:.2%}."
                ),
                value=value,
                confidence=confidence,
            )
            alerts.append(alert)
            self._history.append(alert)
            await self._emit(alert)

        if alerts:
            logger.info(
                "Anomaly alerts raised",
                count=len(alerts),
                source=source,
            )
        return alerts

    async def evaluate_thresholds(
        self,
        df: pd.DataFrame,
        source: str = "threshold_monitor",
    ) -> List[Alert]:
        """Evaluate all registered threshold rules against a DataFrame."""
        alerts: List[Alert] = []

        for rule in self._rules:
            if not rule.enabled or rule.column not in df.columns:
                continue

            breaches = df[df[rule.column].apply(rule.evaluate)]
            for _, row in breaches.iterrows():
                value = float(row[rule.column])
                alert = Alert.create(
                    alert_type="THRESHOLD",
                    priority=rule.priority,
                    source=rule.source,
                    title=f"Threshold breach: {rule.column}",
                    description=(
                        f"Column '{rule.column}' value {value:.4f} "
                        f"{rule.operator} {rule.threshold:.4f}"
                    ),
                    value=value,
                    threshold=rule.threshold,
                )
                alerts.append(alert)
                self._history.append(alert)
                await self._emit(alert)

        return alerts

    def resolve(self, alert_id: str) -> bool:
        """Mark an alert as resolved."""
        for alert in self._history:
            if alert.alert_id == alert_id:
                alert.resolved = True
                alert.resolved_at = datetime.now(timezone.utc)
                return True
        return False

    def get_active_alerts(self, priority: Optional[AlertPriority] = None) -> List[Alert]:
        alerts = [a for a in self._history if not a.resolved]
        if priority:
            alerts = [a for a in alerts if a.priority == priority]
        return sorted(alerts, key=lambda a: a.triggered_at, reverse=True)

    def get_history(self, limit: int = 500) -> List[Alert]:
        return self._history[-limit:]


# Global singleton
alert_engine = AlertEngine()
